param([string]$BackupFolder = $PSScriptRoot)
$ErrorActionPreference = 'Stop'
$backup = (Resolve-Path -LiteralPath $BackupFolder).Path
$receipt = Get-Content -LiteralPath (Join-Path $backup 'receipt.json') -Raw | ConvertFrom-Json
$target = (Resolve-Path -LiteralPath $receipt.gameFolder).Path
if (Get-Process -Name Skate,ReSkateLauncher -ErrorAction SilentlyContinue) { throw 'Close Skate and all ReSkate launcher windows first.' }
foreach ($file in @('ReSkate.dll','ReSkateLauncher.exe')) {
    if (-not (Test-Path -LiteralPath (Join-Path $backup $file))) { throw "Backup missing: $file" }
    if ((Get-FileHash -LiteralPath (Join-Path $target $file)).Hash -ne $receipt.installed.$file) {
        throw 'The installed files changed after this prototype was installed. Restore manually from this backup to avoid overwriting a newer installation.'
    }
}
foreach ($file in @('ReSkate.dll','ReSkateLauncher.exe')) { Copy-Item -LiteralPath (Join-Path $backup $file) -Destination (Join-Path $target $file) -Force }
Write-Host 'Original ReSkate files restored. Backup retained.'
