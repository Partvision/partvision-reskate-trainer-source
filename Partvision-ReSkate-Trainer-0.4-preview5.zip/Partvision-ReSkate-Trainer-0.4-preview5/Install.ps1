param(
    [string]$GameFolder = 'C:\Program Files (x86)\Steam\steamapps\common\Skate',
    [switch]$VerifyOnly
)
$ErrorActionPreference = 'Stop'
$target = (Resolve-Path -LiteralPath $GameFolder).Path
$package = Get-Content -LiteralPath (Join-Path $PSScriptRoot 'build-info.json') -Raw | ConvertFrom-Json
$files = @('ReSkate.dll', 'ReSkateLauncher.exe')
if ((Get-FileHash -LiteralPath (Join-Path $target 'Skate.exe') -Algorithm SHA256).Hash -ne $package.game_sha256) {
    throw 'This Skate.exe does not match the game build checked for this prototype. No files were changed.'
}
foreach ($file in $files) {
    $expected = $package.files.$file
    if ((Get-FileHash -LiteralPath (Join-Path $PSScriptRoot $file) -Algorithm SHA256).Hash -ne $expected) {
        throw "Package verification failed: $file"
    }
    if (-not (Test-Path -LiteralPath (Join-Path $target $file))) { throw "Missing installed file: $file" }
}
if ($VerifyOnly) { Write-Host 'PASS: package and installed game match. No files changed.'; exit 0 }
if (Get-Process -Name Skate,ReSkateLauncher -ErrorAction SilentlyContinue) {
    throw 'Close Skate and all ReSkate launcher windows before installing. No files were changed.'
}
$backup = Join-Path $target ('EarlyTrainerBackups\' + [DateTime]::Now.ToString('yyyyMMdd-HHmmss-fff'))
New-Item -ItemType Directory -Path $backup | Out-Null
foreach ($file in $files) { Copy-Item -LiteralPath (Join-Path $target $file) -Destination (Join-Path $backup $file) }
$receipt = [ordered]@{ gameFolder=$target; installed=$package.files }
$receipt | ConvertTo-Json -Depth 5 | Set-Content -LiteralPath (Join-Path $backup 'receipt.json') -Encoding UTF8
Copy-Item -LiteralPath (Join-Path $PSScriptRoot 'Restore.ps1') -Destination $backup
try {
    foreach ($file in $files) {
        Copy-Item -LiteralPath (Join-Path $PSScriptRoot $file) -Destination (Join-Path $target $file) -Force
        if ((Get-FileHash -LiteralPath (Join-Path $target $file)).Hash -ne $package.files.$file) { throw "Copy failed: $file" }
    }
} catch {
    foreach ($file in $files) { Copy-Item -LiteralPath (Join-Path $backup $file) -Destination (Join-Path $target $file) -Force }
    throw
}
Write-Host "Installed. Start ReSkate normally, load a map, then press Home."
Write-Host "Original files and Restore.ps1: $backup"
