#include "early_trainer.h"
#include "trainer_logic.h"
#include "trainer_storage.h"
#include "ollie_model.h"
#include "trick_model.h"
#include "Engine/Core/Json/json.h"
#include "Engine/Core/Platform/launcher_support.h"
#include "Extension/Skater/physics_tuning.h"
#include "Extension/Skater/client_source_spawn.h"
#include "Extension/Skater/client_source_spawn_internal.h"
#include "Extension/Skater/no_bail.h"
#include "Extension/Settings/named_settings.h"
#include "Extension/Multiplayer/Hud/game_ui_state.h"
#include "Extension/UI/Overlay/input_capture.h"
#include <windows.h>
#include <shlobj.h>
#include <atomic>
#include <chrono>
#include <filesystem>
#include <fstream>
#include <mutex>
#include <map>
#include <algorithm>
#include "Extension/Profile/local_profile_runtime.h"
namespace dingosdk::runtime::detail { bool queue_debug(void*,const overlay::DebugRequest&,char*,std::size_t); }
namespace dingosdk::early_trainer {
namespace {
using storage_detail::encode;
using storage_detail::decode;
std::mutex mutex;
Config options;
std::vector<DisplayRequest> display_queue;
std::atomic<bool> display_wanted{};
std::array<Preset,3> saved;
View published;
std::array<std::atomic<bool>,5> active{},manual{};
std::atomic<bool> reset_pending{},burst_pending{},slingshot_pending{},editing_text{};
std::array<std::atomic<bool>,TweakCount> trick_active{},trick_manual{};
std::atomic<unsigned> opening_key{0x24};
std::atomic<std::uint64_t> revision{0};
std::atomic<float> present_fps{0},present_ms{0};
std::filesystem::path storage() {
    PWSTR raw=nullptr;std::filesystem::path result;
    if(SUCCEEDED(SHGetKnownFolderPath(FOLDERID_LocalAppData,0,nullptr,&raw))&&raw) result=std::filesystem::path(raw)/L"ReSkate"/L"PartvisionTrainer"/L"settings.json";
    if(raw)CoTaskMemFree(raw);return result;
}
void storage_message(const std::string& s){std::lock_guard lock(mutex);published.storage_status=s;}
void load() {
    try{
        const auto path=storage();if(path.empty())return;
        std::ifstream file(path,std::ios::binary);if(!file)return;
        if(std::filesystem::file_size(path)>65536)throw std::runtime_error("Settings file is too large");
        const std::string text((std::istreambuf_iterator<char>(file)),{});const auto j=Json::parse(text);
        if(j.value("schema",0)!=2&&j.value("schema",0)!=3)throw std::runtime_error("Unsupported settings schema");
        auto c=decode(j.at("config"));std::array<Preset,3> presets{};
        if(j.contains("presets"))for(std::size_t i=0;i<3&&i<j.at("presets").size();++i){const auto& p=j.at("presets").at(i);presets[i]={p.value("name","").substr(0,32),decode(p.at("config"))};}
        {std::lock_guard lock(mutex);options=c;saved=presets;published.storage_status="Settings loaded";}opening_key=c.binds[Menu].key;
    }catch(const std::exception& e){storage_message(std::string("Settings not loaded: ")+e.what());}
}
void save() {
    try{
        Config c;std::array<Preset,3> p;{std::lock_guard lock(mutex);c=options;p=saved;}
        Json j=Json::object();j["schema"]=3;j["config"]=encode(c);Json ps=Json::array();
        for(auto& entry:p){Json row=Json::object();row["name"]=entry.name;row["config"]=encode(entry.config);ps.push_back(row);}j["presets"]=ps;
        const auto path=storage();if(path.empty())throw std::runtime_error("Local AppData unavailable");
        std::filesystem::create_directories(path.parent_path());const auto temp=std::filesystem::path(path.wstring()+L".tmp");
        {std::ofstream f(temp,std::ios::binary|std::ios::trunc);f<<j.dump(2);f.flush();if(!f)throw std::runtime_error("Write failed");}
        if(!MoveFileExW(temp.c_str(),path.c_str(),MOVEFILE_REPLACE_EXISTING|MOVEFILE_WRITE_THROUGH))throw std::runtime_error("Replace failed");
        storage_message("Settings saved");
    }catch(const std::exception& e){storage_message(std::string("Settings not saved: ")+e.what());}
}
bool send(overlay::DebugAction action,bool enabled=false,float value=0) {
    char result[256]{};return runtime::detail::queue_debug(nullptr,{action,enabled,value},result,sizeof(result));
}
bool focused(){DWORD pid=0;const auto w=GetForegroundWindow();if(w)GetWindowThreadProcessId(w,&pid);return pid==GetCurrentProcessId();}
double seconds(){return std::chrono::duration<double>(std::chrono::steady_clock::now().time_since_epoch()).count();}
}
void display_observe(bool wanted){display_wanted=wanted;}
void display_request(DisplayRequest request){std::lock_guard lock(mutex);if(display_queue.size()<64)display_queue.push_back(std::move(request));}
Config config(){std::lock_guard lock(mutex);return options;}
bool set_config(Config c,std::string& error){
    if(!normalize(c,error))return false;
    const auto reserved=launcher::overlay_keys();
    std::vector<Binding> all_binds(c.binds.begin(),c.binds.end());all_binds.insert(all_binds.end(),c.tweak_binds.begin(),c.tweak_binds.end());
    for(auto b:all_binds)if(b.key&&(static_cast<unsigned>(b.key)==reserved.menu||static_cast<unsigned>(b.key)==reserved.console)){error="This key opens a ReSkate menu or console. Rebind that first.";return false;}
    {std::lock_guard lock(mutex);options=c;}opening_key=c.binds[Menu].key;++revision;return true;
}
std::array<Preset,3> presets(){std::lock_guard lock(mutex);return saved;}
void save_preset(int slot,const std::string& name){if(slot<0||slot>=3)return;{std::lock_guard lock(mutex);saved[slot]={name.empty()?"My preset":name.substr(0,32),options};}++revision;}
void load_preset(int slot){if(slot<0||slot>=3)return;const auto p=presets();if(!p[slot].name.empty()){std::string error;set_config(p[slot].config,error);}}
void set_active(Action a,bool value){if(a>=0&&a<5){manual[a]=value;active[a]=value;}}
bool is_active(Action a){return a>=0&&a<5?active[a].load():false;}
void emergency_reset(){for(auto& a:active)a=false;for(auto& a:manual)a=false;reset_pending=true;burst_pending=false;slingshot_pending=false;for(auto& a:trick_active)a=false;for(auto& a:trick_manual)a=false;}
void boost_once(){burst_pending=true;}
void slingshot_once(){slingshot_pending=true;}
void set_tweak(Tweak f,bool enabled){if(f>=0&&f<TweakCount){trick_manual[f]=enabled;trick_active[f]=enabled;}}
bool tweak_enabled(Tweak f){return f>=0&&f<TweakCount&&trick_active[f].load();}
View view(){std::lock_guard lock(mutex);auto v=published;for(int i=0;i<5;++i)v.active[i]=active[i].load();for(int i=0;i<TweakCount;++i)v.tweak_active[i]=trick_active[i].load();v.fps=present_fps;v.frame_ms=present_ms;return v;}
void set_text_editing(bool value){editing_text=value;}
unsigned menu_key(){return opening_key.load();}
std::string key_name(int key){
    if(!key)return "Unbound";if(key>=0x70&&key<=0x87)return "F"+std::to_string(key-0x6f);
    if(key>='A'&&key<='Z')return std::string(1,static_cast<char>(key));if(key>='0'&&key<='9')return std::string(1,static_cast<char>(key));
    if(key==VK_HOME)return "Home";if(key==VK_END)return "End";if(key==VK_PRIOR)return "Page Up";if(key==VK_NEXT)return "Page Down";
    char name[64]{};auto scan=MapVirtualKeyA(static_cast<UINT>(key),MAPVK_VK_TO_VSC);if(key>=VK_PRIOR&&key<=VK_DELETE)scan|=0x100;
    if(GetKeyNameTextA(static_cast<LONG>(scan<<16),name,64))return name;return "Key "+std::to_string(key);
}
void observe_debug(const overlay::DebugModel& d){std::lock_guard lock(mutex);published.debug=d;}
void note_present(){static double start=seconds();static unsigned count=0;const double now=seconds();++count;if(now-start>=0.5){const auto fps=static_cast<float>(count/(now-start));present_fps=fps;present_ms=1000/fps;count=0;start=now;}}
void tick(std::uintptr_t base,std::uintptr_t client,bool ready,bool offline,std::string_view map) noexcept {
    static bool loaded=false,previous_offline=true,noclip_owned=false,slow_owned=false;
    static float original_flight=15;
    static Config last_config;static std::array<KeyLatch,ActionCount> keys;
    static std::uint64_t saved_revision=0,seen_revision=0;static ULONGLONG save_at=0,next_boost=0,next_tuning=0,next_time=0,noclip_retry=0;
    static std::string slow_baseline="1";static float actual_time=1,applied=1;
    static std::uintptr_t asset_saved=0,refreshed_entity=0;static TrickMap mappings;static std::array<TrickLease,TweakCount+1> leases;
    static std::array<KeyLatch,TweakCount> trick_keys;
    static Motion motion;static ULONGLONG jump_until=0;static float jump_factor=1;static std::uint64_t jump_boosts=0;
    try {
        if(!loaded){load();loaded=true;last_config=config();}
        const auto now=GetTickCount64();const auto c=config();View v=view();v.ready=ready;v.offline=offline;v.map=map;
        const auto rev=revision.load();if(rev!=seen_revision){seen_revision=rev;save_at=now+600;}
        if(rev!=saved_revision&&now>=save_at){save();saved_revision=rev;}
        if(!offline&&previous_offline)emergency_reset();previous_offline=offline;
        const bool foreground=focused();const bool game_menu=multiplayer::sample_game_ui_state(base).in_menu;
        const bool allowed=foreground&&ready&&offline&&!game_menu&&overlay::keyboard_shortcuts_allowed();
        {overlay::detail::OverlayInputAccess access;
            for(int i=0;i<Menu;++i){const auto b=c.binds[i];const bool raw=b.key&&(GetAsyncKeyState(b.key)&0x8000)!=0;
                if(b.key!=last_config.binds[i].key||b.hold!=last_config.binds[i].hold){keys[i]={raw,raw};if(i<5){active[i]=false;manual[i]=false;}}
                const bool pressed=keys[i].press(raw,allowed||(i==Reset&&foreground&&!editing_text.load()));
                if(i==Reset){if(pressed)emergency_reset();continue;}
                if(b.hold)active[i]=manual[i].load()||keys[i].held(raw,allowed);else {if(pressed)manual[i]=!manual[i].load();active[i]=manual[i].load();}
            }
        }
        for(int i=0;i<TweakCount;++i){const auto b=c.tweak_binds[i];const bool raw=b.key&&(GetAsyncKeyState(b.key)&0x8000)!=0;
            if(b.key!=last_config.tweak_binds[i].key||b.hold!=last_config.tweak_binds[i].hold){trick_keys[i]={raw,raw};trick_active[i]=false;trick_manual[i]=false;}
            const bool pressed=trick_keys[i].press(raw,allowed);
            if(b.hold)trick_active[i]=trick_manual[i].load()||trick_keys[i].held(raw,allowed);
            else{if(pressed)trick_manual[i]=!trick_manual[i].load();trick_active[i]=trick_manual[i].load();}
        }
        last_config=c;
        if(!foreground){active[Boost]=false;active[Noclip]=false;active[Slow]=false;manual[Boost]=false;manual[Noclip]=false;manual[Slow]=false;}
        const bool reset=reset_pending.exchange(false);
        if(reset){for(auto& k:keys)if(k.down)k.blocked_until_release=true;for(auto& k:trick_keys)if(k.down)k.blocked_until_release=true;cancel_jump_scale();jump_until=0;v.jump_status="Disabled";next_tuning=0;next_time=0;}
        // Present only queues requests. Native settings and profile edits stay on the client thread.
        static std::map<std::string,std::string> display_baselines;
        static std::map<std::string,int> graphics_baselines;
        static std::map<overlay::DebugAction,overlay::DebugRequest> camera_baselines;
        std::vector<DisplayRequest> requests;
        {std::lock_guard lock(mutex);requests.swap(display_queue);}
        if(reset){
            requests.clear();
            for(const auto& [key,value]:display_baselines)requests.push_back({DisplayKind::Setting,key,value,{},true});
            for(const auto& [key,value]:graphics_baselines)requests.push_back({DisplayKind::Graphics,key,std::to_string(value),{},true});
            for(const auto& [action,request]:camera_baselines)requests.push_back({DisplayKind::Debug,"","",request,true});
        }
        for(const auto& q:requests){
            bool ok=false;
            if(q.kind==DisplayKind::Setting && std::find(display_settings.begin(),display_settings.end(),q.key)!=display_settings.end()){
                refresh_named_settings(true);
                const auto& values=named_settings_model();
                const auto it=std::find_if(values.begin(),values.end(),[&](const auto& x){return x.name==q.key&&x.available;});
                if(it==values.end()){v.display_status="Setting not available yet: "+q.key;continue;}
                const auto prior=it->value;
                const auto display_baseline=display_baselines.find(q.key);
                if(q.restore&&display_baseline==display_baselines.end())continue;
                v.display_status=player_change_named_setting(q.key,q.restore?display_baseline->second:q.value,false);
                ok=!v.display_status.starts_with("error:");
                if(ok){if(q.restore)display_baselines.erase(q.key);else display_baselines.try_emplace(q.key,prior);}
            }else if(q.kind==DisplayKind::Graphics){
                const auto it=std::find(graphics_keys.begin(),graphics_keys.end(),q.key);
                if(it==graphics_keys.end())continue;
                const auto prior=local_profile_graphics_controls().choices.effects[static_cast<std::size_t>(it-graphics_keys.begin())];
                ok=set_local_graphics_control(q.key,std::stoi(q.value));
                if(ok){if(q.restore)graphics_baselines.erase(q.key);else graphics_baselines.try_emplace(q.key,prior);}
                v.display_status=ok?local_profile_graphics_controls().status:"Graphics change could not be saved.";
            }else if(q.kind==DisplayKind::Debug){
                auto prior=q.debug;
                switch(q.debug.action){
                case overlay::DebugAction::set_free_camera:prior.enabled=v.debug.free_camera;break;
                case overlay::DebugAction::set_free_camera_fov:prior.value=v.debug.free_camera_fov;break;
                default:continue;
                }
                ok=send(q.debug.action,q.debug.enabled,q.debug.value);
                if(ok){if(q.restore)camera_baselines.erase(q.debug.action);else camera_baselines.try_emplace(q.debug.action,prior);}
                v.display_status=ok?"Camera request queued; live state shown below.":"Camera request queue unavailable.";
            }
        }
        static ULONGLONG next_display=0;
        if(display_wanted){refresh_named_settings(true);if(now>=next_display){next_display=now+250;v.display_values.clear();
            for(const auto& x:named_settings_model())if(std::find(display_settings.begin(),display_settings.end(),x.name)!=display_settings.end())v.display_values.push_back(x);
        }}
        overlay::DebugModel skater;
        bool found=false;
        if(ready)try{(void)client_source::detail::debug_skater(base,client,skater);found=skater.skater_position_valid;}catch(...){}
        if(found){watch_physics_state(client,skater.skater_identity);const auto watch=watched_physics_state();v.physics_state=watch.valid?watch.state:0;
            const bool trigger=motion.sample(skater.skater_position,seconds(),skater.skater_identity,v.physics_state,v.debug.noclip||v.debug.free_camera,false);
            v.position=skater.skater_position;v.velocity=motion.velocity;v.telemetry_valid=motion.valid;
            v.horizontal=std::hypot(v.velocity[0],v.velocity[2]);v.airborne=motion.airborne;
            v.air_time=motion.airborne?static_cast<float>(motion.stamp-motion.takeoff_time):0;v.height=motion.airborne?std::max(0.0f,motion.apex-motion.takeoff_y):0;
            v.last_height=motion.last_height;v.last_air_time=motion.last_air;v.jump_count=motion.count;
            if(trigger&&offline&&active[Jump]&&c.jump!=1&&!v.debug.noclip){jump_factor=std::sqrt(c.jump);jump_until=now+250;v.jump_status="Jump detected; waiting for native upward velocity";}
        }else{motion.valid=false;v.telemetry_valid=false;v.airborne=false;cancel_jump_scale();jump_until=0;}
        if(!offline||!active[Jump]||v.debug.noclip){cancel_jump_scale();jump_until=0;v.jump_status="Disabled";}
        if(jump_until){const auto result=take_jump_scale_result();
            if(result.outcome>0){++jump_boosts;jump_until=0;v.jump_status="Applied to an off-board jump";}
            else if(now>=jump_until||result.outcome==-2||result.outcome==-3){cancel_jump_scale();jump_until=0;v.jump_status="No compatible off-board jump velocity found";}
            else (void)queue_jump_scale(client,skater.skater_identity,jump_factor);
        }
        v.offboard_boosts=jump_boosts;
        if(offline&&active[Jump]&&!jump_until&&v.jump_status=="Disabled")v.jump_status="Experimental: waiting for a jump from level ground";
        // Native debug requests always go through ReSkate's existing scheduler and ownership checks.
        const bool want_fly=offline&&ready&&active[Noclip];
        if(want_fly&&now>=noclip_retry&&!v.debug.noclip){
            if(!noclip_owned)original_flight=v.debug.camera_speed;
            if(send(overlay::DebugAction::set_camera_speed,false,c.flight)){noclip_owned=true;send(overlay::DebugAction::set_noclip,true);}
            noclip_retry=now+750;
        }else if(!want_fly&&noclip_owned){if(send(overlay::DebugAction::set_noclip,false)){send(overlay::DebugAction::set_camera_speed,false,original_flight);noclip_owned=false;noclip_retry=0;}}
        if(want_fly&&v.debug.noclip&&std::abs(v.debug.camera_speed-c.flight)>0.01f&&now>=noclip_retry){send(overlay::DebugAction::set_camera_speed,false,c.flight);noclip_retry=now+500;}
        const bool burst=burst_pending.exchange(false);
        if(offline&&ready&&foreground&&!game_menu&&!v.debug.noclip&&(burst||(active[Boost]&&overlay::keyboard_shortcuts_allowed()&&now>=next_boost))){
            if(v.debug.forward_velocity_available&&v.telemetry_valid&&v.horizontal<c.speed_cap){
                const float amount=std::min(c.boost,c.speed_cap-v.horizontal);
                if(amount>=1){send(overlay::DebugAction::set_forward_velocity_speed,false,amount);send(overlay::DebugAction::add_forward_velocity);send(overlay::DebugAction::set_forward_velocity_speed,false,v.debug.forward_velocity_speed);}
            }
            next_boost=now+300;
        }
        const bool launch=slingshot_pending.exchange(false);
        if(launch&&offline&&ready&&foreground&&!game_menu&&!v.debug.noclip&&v.debug.forward_velocity_available&&v.debug.up_velocity_available){
            send(overlay::DebugAction::set_forward_velocity_speed,false,c.slingshot_forward);send(overlay::DebugAction::add_forward_velocity);
            send(overlay::DebugAction::set_forward_velocity_speed,false,v.debug.forward_velocity_speed);
            send(overlay::DebugAction::set_up_velocity_speed,false,c.slingshot_up);send(overlay::DebugAction::add_up_velocity);
            send(overlay::DebugAction::set_up_velocity_speed,false,v.debug.up_velocity_speed);
        }
        // Keep slow motion reversible and report the actual named-setting result.
        const float want_time=offline&&ready&&active[Slow]?c.slow:1;
        if(now>=next_time){next_time=now+200;
            if(want_time!=1&&!slow_owned){refresh_named_settings(true);for(const auto& row:named_settings_model())if(row.name=="SimulationTime.TimeScale"&&row.available){slow_baseline=row.value;slow_owned=true;break;}}
            if(slow_owned){
                if(!offline){slow_owned=false;actual_time=1;v.time_status="Reset by session rules";}
                else {const auto result=player_change_named_setting("SimulationTime.TimeScale",want_time==1?slow_baseline:std::to_string(want_time),false);
                    v.time_status=result;if(!result.starts_with("error:")){actual_time=want_time==1?std::stof(slow_baseline):want_time;if(want_time==1)slow_owned=false;}}
            }else if(want_time!=1)v.time_status="Waiting for SimulationTime.TimeScale";
        }
        v.time_scale=actual_time;
        // Independently capture and restore only each feature's named fields.
        if(now>=next_tuning||reset){next_tuning=now+100;physics_tuning::prepare();std::string error;const auto model=physics_tuning::game_tuning(&error);
            if(!model){v.tuning_available=false;v.status=error.empty()?"Reading physics data...":error;}
            else {
                if(mappings[0].empty())mappings=trick_map(*model);
                physics_tuning::Values live;std::uintptr_t asset=0;
                if(!physics_tuning::read_live(base,live,&asset)){v.tuning_available=false;v.status="Waiting for supported game physics";}
                else {
                    if(asset!=asset_saved){asset_saved=asset;leases={};applied=1;refreshed_entity=0;v.tweak_applied={};}
                    v.tuning_available=found&&offline;v.status=offline?(found?"Ready":"Waiting for skater"):"Player overrides disabled in multiplayer";
                    const auto curve_mappings=trick_curves(*model);auto target=live;std::array<bool,TweakCount+1> wanted_flags{};
                    wanted_flags[0]=offline&&found&&active[Ollie]&&c.ollie!=1;
                    for(int i=0;i<TweakCount;++i){v.tweak_available[i]=!mappings[i+1].empty();wanted_flags[i+1]=offline&&found&&trick_active[i]&&v.tweak_available[i]&&(i==InfiniteFoot||i==MultipleFlips||c.tweaks[i]!=1);}
                    // During temporary skater absence, keep captured leases until the skater returns.
                    if(found||!offline||reset){
                        for(int i=0;i<TweakCount+1;++i)leases[i].compose(target,live,mappings[i],curve_mappings[i],wanted_flags[i],i==0?c.ollie:c.tweaks[i-1]);
                        const auto result=physics_tuning::write_live(base,found?skater.skater_identity:0,target);
                        if(result.failed||result.mismatched){v.status="Tuning write failed; reset and retry";v.tuning_available=false;}
                        else if(found&&refreshed_entity!=skater.skater_identity&&!result.refreshed&&!physics_tuning::refresh_skater(base,skater.skater_identity)){v.status="Waiting for skater physics cache";}
                        else {
                            for(int i=0;i<TweakCount+1;++i)leases[i].completed(wanted_flags[i]);
                            applied=wanted_flags[0]?c.ollie:1;refreshed_entity=found?skater.skater_identity:0;
                            for(int i=0;i<TweakCount;++i)v.tweak_applied[i]=wanted_flags[i+1];
                        }
                    }
                }
            }
        }
        v.applied=applied;
        {std::lock_guard lock(mutex);v.debug=published.debug;v.storage_status=published.storage_status;published=std::move(v);}
    }catch(const std::exception& e){std::lock_guard lock(mutex);published.status=std::string("Trainer: ")+e.what();}
    catch(...){std::lock_guard lock(mutex);published.status="Trainer observation failed";}
}
}

