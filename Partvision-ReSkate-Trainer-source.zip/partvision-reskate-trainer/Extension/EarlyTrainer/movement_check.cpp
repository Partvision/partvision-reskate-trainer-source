#include "Extension/Skater/trainer_movement_step.h"
#include <iostream>
#include <stdexcept>
#include <fstream>
#include <filesystem>
#include "Engine/Game/Build/20260929/trainer_movement.h"
using namespace dingosdk::client_source::detail;
namespace dingosdk::client_source::detail {
bool source_writable(std::uintptr_t address,std::size_t size){
    MEMORY_BASIC_INFORMATION page{};
    return VirtualQuery(reinterpret_cast<const void*>(address),&page,sizeof(page))&&page.State==MEM_COMMIT&&
        !(page.Protect&(PAGE_GUARD|PAGE_NOACCESS))&&(page.Protect&(PAGE_READWRITE|PAGE_EXECUTE_READWRITE|PAGE_WRITECOPY|PAGE_EXECUTE_WRITECOPY))&&
        size<=page.RegionSize&&address-reinterpret_cast<std::uintptr_t>(page.BaseAddress)<=page.RegionSize-size;
}
}
void check(bool value,const char* why){if(!value)throw std::runtime_error(why);}
void check_native_phase(const char* path){
    std::ifstream file(std::filesystem::path(path)/"Skate.exe",std::ios::binary);
    check(bool(file),"Skate.exe missing");const std::vector<char> image((std::istreambuf_iterator<char>(file)),{});
    check(image.size()>sizeof(IMAGE_DOS_HEADER),"PE too small");IMAGE_DOS_HEADER dos{};std::memcpy(&dos,image.data(),sizeof(dos));
    check(dos.e_lfanew>0&&std::size_t(dos.e_lfanew)+sizeof(IMAGE_NT_HEADERS64)<=image.size(),"invalid PE header");
    IMAGE_NT_HEADERS64 nt{};std::memcpy(&nt,image.data()+dos.e_lfanew,sizeof(nt));
    const auto at=[&](std::uintptr_t rva,std::size_t size){
        const auto offset=std::size_t(dos.e_lfanew)+24+nt.FileHeader.SizeOfOptionalHeader;
        for(unsigned i=0;i<nt.FileHeader.NumberOfSections;++i){IMAGE_SECTION_HEADER section{};
            check(offset+(i+1)*sizeof(section)<=image.size(),"section table truncated");std::memcpy(&section,image.data()+offset+i*sizeof(section),sizeof(section));
            if(rva>=section.VirtualAddress&&rva+size<=std::uintptr_t(section.VirtualAddress)+section.SizeOfRawData){
                const auto raw=section.PointerToRawData+rva-section.VirtualAddress;check(raw+size<=image.size(),"section truncated");return image.data()+raw;
            }
        }throw std::runtime_error("RVA unmapped");
    };
    const auto pointer=[&](std::uintptr_t rva){std::uint64_t value{};std::memcpy(&value,at(rva,8),8);return value-nt.OptionalHeader.ImageBase;};
    namespace native=dingosdk::game::build::v20260929::trainer_movement;
    check(pointer(0x6176d30+native::movement_core_slot)==native::movement_update_contract.rva,"hook is not the native movement phase");
    check(std::memcmp(at(native::movement_update_contract.rva,32),native::movement_update_contract.bytes.data(),32)==0,"movement phase code differs");
    check(pointer(0x65e8f40+0x10)==0x4822b80&&pointer(0x65e8c20+0x18)==0x48318a0&&pointer(0x65e8da0+0x18)==0x4820860,"walking/falling dispatch differs");
    const unsigned char dispatch[]{0x48,0x8b,0x4f,0x48,0x48,0x8b,0xd7,0x48,0x8b,0x01,0xff,0x50,0x18};
    check(std::memcmp(at(0x4822c85,sizeof(dispatch)),dispatch,sizeof(dispatch))==0,"consumer phase does not dispatch movement");
    check(pointer(0x65e8c20+0x20)==0x1f9630&&pointer(0x65e8da0+0x20)==0x1f9630,"old phase reproduction changed");
}
int main(int argc,char** argv){try{
    if(argc>1)check_native_phase(argv[1]);
    using namespace dingosdk::early_trainer;
    const auto v=walking_velocity({1000,20,-1000},{1000.25f,99,-1000.5f},4,.125f);
    check(v==std::array<float,3>{8,0,-16},"walking scaled world position instead of local displacement");
    check(walking_velocity({0,0,0},{.25f,99,-.5f},4,.125f)==v,"walking changes with map origin");
    check(walking_velocity({10,20,30},{10,25,30},20,.02f)==std::array<float,3>{},"idle or vertical movement gains horizontal speed");
    for(float factor:{0.f,.5f,1.f,5.f}){float velocity=0;for(int step=0;step<100;++step)velocity+=-10*.01f+gravity_correction(-10,factor,.01f);
        check(std::abs(velocity-(-10*factor))<.001f,"body gravity compensation does not match requested acceleration");}

    // Reproduce preview 4 with the actual SourceReader and writable native memory.
    float gravity=-9.81f;auto address=reinterpret_cast<std::uintptr_t>(&gravity);
    SourceReader old_reader;const float old=old_reader.value<float>(address);debug_write(address,old*.5f);
    bool self_rejected=false;try{old_reader.verify();}catch(const SourceGuard&){self_rejected=true;}
    check(self_rejected,"old write/verify regression was not reproduced");gravity=old;
    struct NativeContext{float x=3,y=7,z=-4,gravity=-9.81f;std::uint32_t owner=42;} context;
    for(int step=0;step<100;++step){
        SourceReader reader;MovementStepPatch patch;const auto base=reinterpret_cast<std::uintptr_t>(&context);
        (void)reader.value<std::uint32_t>(base+offsetof(NativeContext,owner));
        patch.scale(reader,base+offsetof(NativeContext,x),4);patch.scale(reader,base+offsetof(NativeContext,z),4);
        patch.scale(reader,base+offsetof(NativeContext,gravity),step%2?.5f:0);patch.commit(reader);
        // Values seen by the native update, before the post-call restore.
        check(context.x==12&&context.z==-16&&context.y==7,"native consumer never saw speed patch");
        check(context.gravity==(step%2?-4.905f:0),"native consumer never saw gravity patch");
        patch.restore();check(context.x==3&&context.z==-4&&context.gravity==-9.81f,"per-step values compounded or failed to restore");
    }
    SourceReader changed;MovementStepPatch denied;
    denied.scale(changed,reinterpret_cast<std::uintptr_t>(&context.x),2);
    (void)changed.value<std::uint32_t>(reinterpret_cast<std::uintptr_t>(&context.owner));context.owner=43;
    bool rejected=false;try{denied.commit(changed);}catch(const SourceGuard&){rejected=true;}
    denied.restore();check(rejected&&context.x==3,"ownership change allowed native writes");
    SourceReader writer;MovementStepPatch owned;owned.scale(writer,reinterpret_cast<std::uintptr_t>(&context.x),2);owned.commit(writer);
    context.x=11;owned.restore();check(context.x==11,"restoration clobbered a native writer");
    std::cout<<"PASS: native movement dispatch verified against Skate.exe; world-position invariant walking, body gravity compensation; preview4 self-rejection reproduced with actual SourceReader; native consumer sees walking speed and gravity patches for 100 updates; exact/zero-gravity restoration, ownership-change rejection and native-writer preservation.\n";
    return 0;
}catch(const SourceGuard& issue){std::cerr<<issue.message;return 1;}catch(const std::exception& issue){std::cerr<<issue.what();return 1;}}
