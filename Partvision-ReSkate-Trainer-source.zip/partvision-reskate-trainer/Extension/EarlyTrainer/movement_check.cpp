#include "Extension/Skater/trainer_movement_step.h"
#include <iostream>
#include <stdexcept>
using namespace dingosdk::client_source::detail;
namespace dingosdk::client_source::detail {
bool source_writable(std::uintptr_t address,std::size_t size){
    MEMORY_BASIC_INFORMATION page{};
    return VirtualQuery(reinterpret_cast<const void*>(address),&page,sizeof(page))&&page.State==MEM_COMMIT&&
        !(page.Protect&(PAGE_GUARD|PAGE_NOACCESS))&&(page.Protect&(PAGE_READWRITE|PAGE_EXECUTE_READWRITE|PAGE_WRITECOPY|PAGE_EXECUTE_WRITECOPY))&&
        size<=page.RegionSize&&address-reinterpret_cast<std::uintptr_t>(page.BaseAddress)<=page.RegionSize-size;
}
}
void check(bool value,const char* why){if(!value)throw std::runtime_error(why);}
int main(){try{
    // Reproduce preview 4 with the actual SourceReader and writable native memory.
    float gravity=-9.81f;auto address=reinterpret_cast<std::uintptr_t>(&gravity);
    SourceReader old_reader;const float old=old_reader.value<float>(address);debug_write(address,old*.5f);
    bool self_rejected=false;try{old_reader.verify();}catch(const SourceGuard&){self_rejected=true;}
    check(self_rejected,"old write/verify regression was not reproduced");gravity=old;
    struct NativeContext{float x=3,y=7,z=-4,gravity=-9.81f;std::uint32_t owner=42;} context;
    for(int step=0;step<100;++step){
        SourceReader reader;MovementStepPatch patch;const auto base=reinterpret_cast<std::uintptr_t>(&context);
        (void)reader.value<std::uint32_t>(base+offsetof(NativeContext,owner));
        patch.scale(reader,base+offsetof(NativeContext,x),4);patch.scale(reader,base+offsetof(NativeContext,z),4);
        patch.scale(reader,base+offsetof(NativeContext,gravity),step%2?.5f:0);patch.commit(reader);
        // Values seen by the native update, before the post-call restore.
        check(context.x==12&&context.z==-16&&context.y==7,"native consumer never saw speed patch");
        check(context.gravity==(step%2?-4.905f:0),"native consumer never saw gravity patch");
        patch.restore();check(context.x==3&&context.z==-4&&context.gravity==-9.81f,"per-step values compounded or failed to restore");
    }
    SourceReader changed;MovementStepPatch denied;
    denied.scale(changed,reinterpret_cast<std::uintptr_t>(&context.x),2);
    (void)changed.value<std::uint32_t>(reinterpret_cast<std::uintptr_t>(&context.owner));context.owner=43;
    bool rejected=false;try{denied.commit(changed);}catch(const SourceGuard&){rejected=true;}
    denied.restore();check(rejected&&context.x==3,"ownership change allowed native writes");
    SourceReader writer;MovementStepPatch owned;owned.scale(writer,reinterpret_cast<std::uintptr_t>(&context.x),2);owned.commit(writer);
    context.x=11;owned.restore();check(context.x==11,"restoration clobbered a native writer");
    std::cout<<"PASS: preview4 self-rejection reproduced with actual SourceReader; native consumer sees walking speed and gravity patches for 100 updates; exact/zero-gravity restoration, ownership-change rejection and native-writer preservation.\n";
    return 0;
}catch(const SourceGuard& issue){std::cerr<<issue.message;return 1;}catch(const std::exception& issue){std::cerr<<issue.what();return 1;}}
