#include "trainer_logic.h"
#include "trainer_storage.h"
#include <iostream>
#include <limits>
using namespace dingosdk::early_trainer;
void check(bool pass,const char* label){if(!pass)throw std::runtime_error(label);}
int main(){try{
    Config c;std::string error;check(normalize(c,error),"default bindings rejected");
    auto duplicate=c;duplicate.binds[Ollie].key=duplicate.binds[Slow].key;check(!normalize(duplicate,error),"duplicate accepted");
    auto reserved=c;reserved.binds[Menu].key='W';check(!normalize(reserved,error),"flight key accepted");
    auto unbound=c;unbound.binds[Ollie].key=0;unbound.binds[Boost].key=0;check(normalize(unbound,error),"unbound duplicates rejected");
    c.ollie=std::numeric_limits<float>::quiet_NaN();c.slow=-1;c.jump=99;check(normalize(c,error)&&c.ollie==2&&c.slow==0.1f&&c.jump==20,"bounds");
    c.ui_scale=9;c.tweaks[FootSpeed]=0;c.tweaks[FlipSpeed]=std::numeric_limits<float>::quiet_NaN();
    check(normalize(c,error)&&c.ui_scale==1.5f&&c.tweaks[FootSpeed]==0.25f&&c.tweaks[FlipSpeed]==1.5f,"0.4 bounds");
    c.tweak_binds[FootSpeed]={0x7a,true};
    auto conflict=c;conflict.tweak_binds[FootHeight]=conflict.binds[Ollie];check(!normalize(conflict,error),"new binding conflict accepted");
    const auto data=storage_detail::encode(c).dump(2);const auto restored=storage_detail::decode(dingosdk::Json::parse(data));
    check(restored.jump==c.jump&&restored.slow==c.slow&&restored.binds[Slow].hold&&restored.binds[Reset].key==0x23,"settings roundtrip");
    check(restored.ui_scale==1.5f&&restored.tweaks[FootSpeed]==0.25f&&restored.tweak_binds[FootSpeed].key==0x7a&&restored.tweak_binds[FootSpeed].hold,"0.4 persistence");
    Config custom;custom.ollie=25;custom.tweaks[FootSpeed]=12.5f;custom.tweaks[FootHeight]=8;custom.jump=10;custom.speed_cap=400;
    check(normalize(custom,error)&&custom.ollie==25&&custom.tweaks[FootSpeed]==12.5f&&custom.jump==10&&custom.speed_cap==400,"manual values clamped to drag bounds");
    auto saved=storage_detail::decode(storage_detail::encode(custom));check(saved.ollie==25&&saved.tweaks[FootSpeed]==12.5f&&saved.tweaks[FootHeight]==8,"manual values did not persist");
    check(manual_number_valid(12.5f,0.25f,1000)&&!manual_number_valid(std::numeric_limits<float>::infinity(),0.25f,1000)&&!manual_number_valid(-1,0.25f,1000)&&!manual_number_valid(1001,0.25f,1000),"manual entry validation");
    auto legacy=storage_detail::encode(Config{});legacy.erase("tweaks");legacy.erase("tweak_bindings");legacy.erase("ui_scale");
    check(storage_detail::decode(legacy).ui_scale==1,"old config migration");
    auto broken=storage_detail::encode(c);broken["bindings"]=dingosdk::Json::array();bool rejected=false;
    try{(void)storage_detail::decode(broken);}catch(...){rejected=true;}check(rejected,"bad config accepted");
    auto old_bindings=storage_detail::encode(Config{});dingosdk::Json old_array=dingosdk::Json::array();for(int i=0;i<ActionCount;++i)if(i!=NoFall)old_array.push_back(old_bindings["bindings"].at(i));old_bindings["bindings"]=old_array;
    const auto migrated=storage_detail::decode(old_bindings);
    check(migrated.binds[NoFall].key==0&&migrated.binds[Reset].key==0x23&&migrated.binds[Menu].key==0x24,"legacy action migration");
    Config nofall_config;nofall_config.binds[NoFall]={0x7a,true};const auto nofall_saved=storage_detail::decode(storage_detail::encode(nofall_config));
    check(nofall_saved.binds[NoFall].key==0x7a&&nofall_saved.binds[NoFall].hold,"No Fall binding persistence");
    NoFallOverride protection;
    check(!protection.request(true,false,false,0)&&!protection.owned,"No Fall captured unavailable state");
    check(protection.request(true,false,true,0)==true&&protection.owned&&!protection.baseline,"No Fall enable request");
    check(!protection.request(true,false,true,100),"No Fall queue retry spam");
    check(protection.request(true,false,true,500)==true,"No Fall queue retry missing");
    check(!protection.request(true,true,true,501),"No Fall repeats observed state");
    check(protection.request(false,true,false,502)==false&&protection.owned,"No Fall release must queue even without skater");
    protection.submitted(false,true);
    check(!protection.request(false,false,false,503)&&!protection.owned,"No Fall release not confirmed");
    check(!protection.request(true,true,true,504)&&protection.baseline,"Existing native preference lost");
    check(protection.request(false,true,true,505)==true,"Reset lost pre-existing no-bail preference");protection.submitted(false,true);
    check(!protection.request(false,true,true,506)&&!protection.owned,"Native baseline restoration not confirmed");
    NoFallOverride quick;
    check(quick.request(true,false,true,0)==true,"Quick toggle enable missing");
    check(quick.request(false,false,true,1)==false&&quick.owned,"Pending enable not canceled");
    quick.submitted(false,false);check(!quick.request(false,false,true,2)&&quick.owned,"Failed restore queue lost ownership");
    check(quick.request(false,true,true,501)==false,"Failed restore was not retried");quick.submitted(false,true);
    check(quick.request(true,true,true,502)==true,"Pending restore not canceled on re-enable");
    KeyLatch k;check(!k.press(true,false),"blocked key fired");check(!k.press(true,true)&&!k.held(true,true),"held key fired after menu exit");
    check(!k.press(false,true)&&k.press(true,true),"new press missing");check(!k.press(true,true)&&k.held(true,true),"repeat edge");
    k.blocked_until_release=true;check(!k.held(true,true),"emergency latch");k.press(false,true);check(k.press(true,true),"release rearm");
    Motion m;m.sample({0,0,0},1,1,100,false,false);m.sample({0,1,0},1.1,1,200,false,false);m.sample({0,2,0},1.2,1,200,false,false);
    m.sample({0,0,0},1.3,1,100,false,false);check(m.count==1&&m.last_height==2,"peak height");
    m.sample({0,100,0},1.4,1,200,false,false);check(!m.airborne&&m.velocity[1]==0,"teleport reset");
    m.sample({0,101,0},1.5,2,200,false,false);check(!m.airborne,"respawn reset");
    Motion walk;walk.sample({0,0,0},1,1,504,false,false);
    for(int i=1;i<=4;++i)walk.sample({0,0,0},1+i*0.1,1,504,false,false);
    check(walk.sample({0,0.3f,0},1.5,1,504,false,false),"walking jump not detected");
    check(!walk.sample({0,0.6f,0},1.6,1,504,false,false),"jump applied twice");
    Motion hippy;hippy.sample({0,0,0},1,1,100,false,false);check(!hippy.sample({0,0.3f,0},1.1,1,504,false,false),"hippy misclassified as walking jump");
    std::cout<<"PASS: No Fall ownership/retries/restoration and binding migration; config bounds, binding conflicts, persistence roundtrip, malformed config, input suppression/rearm, jump height, teleport/respawn reset, off-board detection.\n";
    return 0;
}catch(const std::exception& e){std::cerr<<"FAIL: "<<e.what()<<'\n';return 1;}}
