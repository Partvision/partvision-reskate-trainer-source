#include "early_trainer.h"
#include "Engine/Game/Build/supported_build.h"
#include <imgui.h>
#include <array>
#include <cstdio>
#include <algorithm>
#include <cstdlib>
namespace dingosdk::early_trainer {
namespace {
std::string feedback;
int recording=-1;
int selected_tab=0;
void apply(Config& c){std::string error;if(!set_config(c,error))feedback=error;else feedback.clear();}
void label(const char* title,const char* detail=nullptr){ImGui::TextUnformatted(title);if(detail)ImGui::TextDisabled("%s",detail);ImGui::Spacing();}
void row(const char* name,const std::string& value){ImGui::TableNextRow();ImGui::TableNextColumn();ImGui::TextDisabled("%s",name);ImGui::TableNextColumn();ImGui::TextWrapped("%s",value.c_str());}
std::string number(float value,const char* unit=""){char b[80];std::snprintf(b,sizeof(b),"%.2f %s",value,unit);return b;}
void toggle(Action action,const char* title){bool enabled=is_active(action);if(ImGui::Checkbox(title,&enabled))set_active(action,enabled);}
void slider(const char* name,float& value,float low,float high,const char* format,Config& c){ImGui::SetNextItemWidth(-160);if(ImGui::SliderFloat(name,&value,low,high,format,ImGuiSliderFlags_AlwaysClamp))apply(c);}
ImGuiKey imgui_key(int vk){
    if(vk>='A'&&vk<='Z')return static_cast<ImGuiKey>(ImGuiKey_A+vk-'A');
    if(vk>='0'&&vk<='9')return static_cast<ImGuiKey>(ImGuiKey_0+vk-'0');
    if(vk>=0x70&&vk<=0x87)return static_cast<ImGuiKey>(ImGuiKey_F1+vk-0x70);
    switch(vk){case 0x20:return ImGuiKey_Space;case 0x21:return ImGuiKey_PageUp;case 0x22:return ImGuiKey_PageDown;
    case 0x23:return ImGuiKey_End;case 0x24:return ImGuiKey_Home;case 0x25:return ImGuiKey_LeftArrow;case 0x26:return ImGuiKey_UpArrow;
    case 0x27:return ImGuiKey_RightArrow;case 0x28:return ImGuiKey_DownArrow;case 0x2e:return ImGuiKey_Delete;
    case 0x08:return ImGuiKey_Backspace;case 0xbd:return ImGuiKey_Minus;case 0xbb:return ImGuiKey_Equal;default:return ImGuiKey_None;}
}
void keybinds(Config& c){
    if(!ImGui::CollapsingHeader("Keybinds and presets")){recording=-1;return;}
    ImGui::TextWrapped("Hold adds a temporary activation. The feature checkbox stays on until you switch it off. Hotkeys pause in menus and chat; emergency reset also works with this menu open.");
    if(ImGui::BeginTable("bindings",4,ImGuiTableFlags_SizingStretchProp|ImGuiTableFlags_RowBg)){
        for(int i=0;i<ActionCount;++i){ImGui::PushID(i);ImGui::TableNextRow();ImGui::TableNextColumn();ImGui::TextUnformatted(action_names[i]);ImGui::TableNextColumn();
            const auto text=recording==i?"Press a key...":key_name(c.binds[i].key);
            if(ImGui::Button(text.c_str(),ImVec2(-1,0)))recording=i;
            ImGui::TableNextColumn();ImGui::BeginDisabled(i>=Reset);if(ImGui::Checkbox("Hold",&c.binds[i].hold))apply(c);ImGui::EndDisabled();
            ImGui::TableNextColumn();ImGui::BeginDisabled(i>=Reset);if(ImGui::SmallButton("Unbind")){c.binds[i].key=0;apply(c);}ImGui::EndDisabled();ImGui::PopID();}
        ImGui::EndTable();
    }
    if(ImGui::BeginTable("trick_bindings",4,ImGuiTableFlags_SizingStretchProp|ImGuiTableFlags_RowBg)){
        for(int i=0;i<TweakCount;++i){ImGui::PushID(100+i);ImGui::TableNextRow();ImGui::TableNextColumn();ImGui::TextUnformatted(tweak_names[i]);ImGui::TableNextColumn();
            const auto text=recording==ActionCount+i?"Press a key...":key_name(c.tweak_binds[i].key);
            if(ImGui::Button(text.c_str(),ImVec2(-1,0)))recording=ActionCount+i;
            ImGui::TableNextColumn();if(ImGui::Checkbox("Hold",&c.tweak_binds[i].hold))apply(c);
            ImGui::TableNextColumn();if(ImGui::SmallButton("Unbind")){c.tweak_binds[i].key=0;apply(c);}ImGui::PopID();}
        ImGui::EndTable();
    }
    if(recording>=0){
        ImGui::TextDisabled("Escape cancels. Duplicate and reserved keys are rejected.");
        if(ImGui::IsKeyPressed(ImGuiKey_Escape,false))recording=-1;
        else for(int vk=8;vk<255;++vk){auto key=imgui_key(vk);if(key!=ImGuiKey_None&&ImGui::IsKeyPressed(key,false)){if(recording<ActionCount)c.binds[recording].key=vk;else c.tweak_binds[recording-ActionCount].key=vk;apply(c);recording=-1;break;}}
    }
    ImGui::Separator();
    static int slot=0;static char name[33]="My preset";
    ImGui::SetNextItemWidth(110);ImGui::Combo("Slot",&slot,"Slot 1\0Slot 2\0Slot 3\0");ImGui::SameLine();ImGui::SetNextItemWidth(180);ImGui::InputText("Name",name,sizeof(name));
    if(ImGui::Button("Save values")){save_preset(slot,name);feedback="Preset saved. Activation switches are not saved.";}ImGui::SameLine();
    const auto p=presets();ImGui::BeginDisabled(p[slot].name.empty());if(ImGui::Button("Load values")){load_preset(slot);c=config();feedback="Preset loaded. Enable the features you want.";}ImGui::EndDisabled();ImGui::SameLine();ImGui::TextDisabled("%s",p[slot].name.empty()?"Empty slot":p[slot].name.c_str());
    if(ImGui::Button("Default values and bindings")){emergency_reset();c=Config{};apply(c);}
    ImGui::TextDisabled("Other game bindings are not exhaustively checked. F-keys are recommended.");
}
void home(const View& v,const overlay::Model& m,Config& c){
    label("YOUR SESSION","Live diagnostics from the game");
    std::string map=v.map.empty()?"Not in a map":v.map;
    for(const auto& level:m.levels)if(v.map.starts_with(level.asset)&&!level.display_name.empty()){map=level.display_name;break;}
    if(ImGui::BeginTable("session",2,ImGuiTableFlags_RowBg|ImGuiTableFlags_SizingStretchProp)){
        row("Map",map);row("Session",v.offline?"Solo":m.multiplayer.hosting?"Hosting":"Multiplayer guest");
        row("Players",v.offline?"1":std::to_string(m.multiplayer.players));row("FPS / frame time",number(v.fps)+" / "+number(v.frame_ms,"ms"));
        row("X / Y / Z",v.telemetry_valid?number(v.position[0])+" / "+number(v.position[1])+" / "+number(v.position[2]):"Waiting for skater");
        row("Trainer",version);row("ReSkate base","1.0.6");row("Game build",std::string(supported_build::steam_build_id));ImGui::EndTable();
    }
    unsigned count=0;for(bool enabled:v.active)count+=enabled?1u:0u;for(bool enabled:v.tweak_active)count+=enabled?1u:0u;
    ImGui::Text("Player switches enabled: %u",count);
    slider("UI scale",c.ui_scale,0.75f,1.5f,"%.2fx",c);
    if(ImGui::SmallButton("Reset UI scale")){c.ui_scale=1;apply(c);}
    ImGui::Spacing();ImGui::TextWrapped("%s",v.status.c_str());
    ImGui::TextWrapped("Open Player for movement controls. Visual and Performance contain camera, effects and rendering controls. Lobby is planned. Player overrides in this preview are available in solo play.");
}
void player(const View& v,Config& c){
    label("PLAYER","Native movement controls and experimental jump tuning");
    ImGui::BeginDisabled(!v.ready||!v.offline);
    if(ImGui::CollapsingHeader("0.4 Tricks",ImGuiTreeNodeFlags_DefaultOpen)){
        for(int i=0;i<TweakCount;++i){ImGui::PushID(200+i);ImGui::BeginDisabled(!v.tuning_available||!v.tweak_available[i]);
            bool enabled=tweak_enabled(static_cast<Tweak>(i));if(ImGui::Checkbox(tweak_names[i],&enabled))set_tweak(static_cast<Tweak>(i),enabled);
            ImGui::SameLine();if(v.tweak_applied[i])ImGui::TextColored(ImVec4(0.3f,0.8f,1,1),"OVERRIDE");
            if(i!=InfiniteFoot&&i!=MultipleFlips)slider("Tuning factor",c.tweaks[i],0.25f,3,"%.2fx",c);
            if(ImGui::SmallButton("Restore native value")){set_tweak(static_cast<Tweak>(i),false);c.tweaks[i]=Config{}.tweaks[i];apply(c);}
            ImGui::EndDisabled();
            if(!v.tweak_available[i])ImGui::TextDisabled("Waiting for compatible named tuning fields");
            if(i==FootSpeed)ImGui::TextWrapped("Scales footplant standstill launch speed and launch speed limit. Does not change animation speed.");
            if(i==FootHeight)ImGui::TextWrapped("Scales footplant upward takeoff velocity. This is launch power, not a measured height multiplier.");
            if(i==InfiniteFoot)ImGui::TextWrapped("Experimental: removes the per-plant pop-decay multiplier. Infinite chaining is not verified.");
            if(i==MultipleFlips)ImGui::TextWrapped("Disables the native perfect-body-flip single-rotation constraint. The supported game's default is already off; board kickflips are separate.");
            if(i==FlipSpeed)ImGui::TextWrapped("Scales body-flip strength and speed limit. Test with Allow Multiple Body Flips enabled.");
            if(i==SpinSpeed)ImGui::TextWrapped("Scales body-spin response graphs and automatic spin speed limit.");
            ImGui::Separator();ImGui::PopID();
        }
        ImGui::TextWrapped("New trick controls are experimental and solo-only. Values and bindings persist; enable switches start off. Each reset restores this feature's captured fields.");
    }
    if(ImGui::CollapsingHeader("Slingshot (experimental)")){
        slider("Forward impulse",c.slingshot_forward,1,50,"+%.1f m/s",c);slider("Upward impulse",c.slingshot_up,1,25,"+%.1f m/s",c);
        ImGui::BeginDisabled(!v.debug.forward_velocity_available||!v.debug.up_velocity_available||v.debug.noclip);
        if(ImGui::Button("Launch once"))slingshot_once();ImGui::EndDisabled();
        if(ImGui::SmallButton("Reset slingshot values")){c.slingshot_forward=20;c.slingshot_up=10;apply(c);}
        ImGui::TextWrapped("One forward and one upward boost through ReSkate's native scheduler. Requires being on the board; existing velocity is not undone by reset.");
    }
    if(ImGui::CollapsingHeader("Ollie, movement and off-board")){
    ImGui::BeginDisabled(!v.tuning_available);toggle(Ollie,"Ollie Power");slider("Power",c.ollie,0.25f,10,"%.2fx",c);ImGui::EndDisabled();
    ImGui::TextDisabled("Applied %.2fx. This scales tuning, not measured jump height.",v.applied);
    if(ImGui::SmallButton("Reset ollie")){set_active(Ollie,false);c.ollie=2;apply(c);}
    ImGui::Separator();toggle(Slow,"Slow motion");slider("Time scale",c.slow,0.1f,1,"%.2fx",c);ImGui::TextDisabled("Applied time scale: %.2fx",v.time_scale);
    if(ImGui::SmallButton("Reset time")){set_active(Slow,false);c.slow=0.5f;apply(c);}ImGui::SameLine();ImGui::TextWrapped("%s",v.time_status.c_str());
    ImGui::Separator();toggle(Boost,"Repeated speed boost");slider("Burst strength",c.boost,1,50,"+%.1f m/s",c);slider("Boost cutoff",c.speed_cap,5,150,"%.1f m/s",c);
    if(ImGui::Button("Single burst"))boost_once();ImGui::SameLine();if(ImGui::SmallButton("Reset boost")){set_active(Boost,false);c.boost=10;c.speed_cap=35;apply(c);}
    ImGui::TextWrapped("Boosts repeat every 0.3 s while active. Cutoff uses measured wall-clock speed; it is not a hard speed limiter. Requires being on the board.");
    if(!v.debug.forward_velocity_available)ImGui::TextDisabled("%s",v.debug.forward_velocity_unavailable.c_str());
    ImGui::Separator();toggle(Noclip,"Noclip / Fly");constexpr float flight_values[]{0.6f,3,5,15,60,300,1500};int selected=3;for(int i=0;i<7;++i)if(c.flight==flight_values[i])selected=i;
    if(ImGui::Combo("Flight speed",&selected,"0.6\0" "3\0" "5\0" "15\0" "60\0" "300\0" "1500\0")){c.flight=flight_values[selected];apply(c);}
    ImGui::TextDisabled("Actual flight: %s",v.debug.noclip?"ON":"OFF");
    ImGui::TextWrapped("Close the menu. WASD moves, Q/E changes altitude, Shift boosts. Existing controller flight controls also work.");
    if(ImGui::SmallButton("Reset flight")){set_active(Noclip,false);c.flight=15;apply(c);}
    if(!v.debug.noclip_available&&!v.debug.noclip)ImGui::TextDisabled("%s",v.debug.noclip_unavailable.c_str());
    ImGui::Separator();toggle(Jump,"Off-board Jump Height (experimental)");slider("Jump factor",c.jump,0.25f,5,"%.2fx",c);
    ImGui::TextWrapped("Attempts one upward-velocity adjustment when a jump starts after stable off-board movement. Test on level ground; slopes can affect detection. This is not a calibrated height multiplier.");
    ImGui::TextDisabled("%s | applied jumps: %llu",v.jump_status.c_str(),static_cast<unsigned long long>(v.offboard_boosts));
    if(ImGui::SmallButton("Reset jump")){set_active(Jump,false);c.jump=1.5f;apply(c);}
    }
    ImGui::EndDisabled();
    ImGui::Separator();label("JUMP MEASUREMENT");
    ImGui::Text("Last on-board jump: %.2f m peak / %.2f s airtime",v.last_height,v.last_air_time);
    if(v.airborne)ImGui::Text("Current: %.2f m / %.2f s",v.height,v.air_time);
    ImGui::TextDisabled("Compare flat-ground jumps at the same speed. Airtime uses wall clock.");
    if(ImGui::CollapsingHeader("Planned player features"))ImGui::TextWrapped("Remaining 0.4 work: Off-Board Speed, verified Off-Board Jump Height, Air Control, Gravity Multiplier, board flip behavior, controller bindings and in-game validation of new trick tuning.");
}
void visual(const View& v,const overlay::Model& m){
    label("VISUAL","Camera and local post-processing");
    ImGui::BeginDisabled(!v.ready||!v.debug.camera_available);
    bool free=v.debug.free_camera;
    if(ImGui::Checkbox("Freecam",&free))display_request({DisplayKind::Debug,"","",{overlay::DebugAction::set_free_camera,free,0}});
    ImGui::TextWrapped("Close this menu to move the camera. WASD moves, Q/E changes altitude, Shift boosts.");
    static float fov=90;
    ImGui::SetNextItemWidth(270);ImGui::SliderFloat("Freecam FOV",&fov,40,120,"%.0f degrees",ImGuiSliderFlags_AlwaysClamp);
    if(ImGui::Button("Apply FOV"))display_request({DisplayKind::Debug,"","",{overlay::DebugAction::set_free_camera_fov,false,fov}});
    ImGui::SameLine();if(ImGui::Button("Game FOV"))display_request({DisplayKind::Debug,"","",{overlay::DebugAction::set_free_camera_fov,false,0}});
    ImGui::TextDisabled("Live override: %.0f (0 = game default)",v.debug.free_camera_fov);
    ImGui::EndDisabled();
    ImGui::TextWrapped("%s",v.debug.status.c_str());
    ImGui::TextWrapped("FOV currently applies to freecam only. ReSkate 1.0.6 supports 40-120 degrees here; 140 remains planned.");
    ImGui::Separator();label("POST-PROCESSING","Default follows the map's authored settings");
    constexpr const char* titles[]{"Film grain","Vignette","Chromatic aberration"};
    for(int i=0;i<3;++i){ImGui::PushID(i);int choice=m.graphics.choices.effects[i]+1;
        ImGui::BeginDisabled(!m.graphics.available);ImGui::SetNextItemWidth(160);
        if(ImGui::Combo(titles[i],&choice,"Default\0Off\0On\0"))display_request({DisplayKind::Graphics,graphics_keys[i],std::to_string(choice-1)});
        ImGui::EndDisabled();ImGui::TextDisabled("Observed: %s",m.graphics.ready[i]?(m.graphics.enabled[i]?"On":"Off"):"Waiting for renderer");ImGui::PopID();}
    ImGui::TextWrapped("Effect choices are saved by ReSkate. Emergency reset restores values changed through this menu during this session.");
    ImGui::TextWrapped("%s",v.display_status.c_str());
    if(ImGui::CollapsingHeader("Planned visuals"))ImGui::TextWrapped("Pedestrian / traffic draw distance, general gameplay FOV, Sword Board and sky color.");
}
void performance(const View& v){
    label("PERFORMANCE","Live frame rate and experimental rendering tweaks");
    ImGui::Text("%.1f FPS  |  %.2f ms/frame",v.fps,v.frame_ms);
    static float before=0;if(ImGui::Button("Capture comparison"))before=v.fps;
    if(before>0)ImGui::Text("Captured %.1f FPS  |  change %+.1f FPS",before,v.fps-before);
    ImGui::TextWrapped("Compare from the same position with the menu in the same state. This is a live sample, not a benchmark.");
    ImGui::Separator();
    constexpr const char* titles[]{"Shadow maps","Detail distance","Short distance","Medium distance","Long distance","Extra-long distance"};
    static std::array<float,6> draft{};static std::array<bool,6> initialized{};
    for(std::size_t i=0;i<display_settings.size();++i){ImGui::PushID(static_cast<int>(i));
        const auto it=std::find_if(v.display_values.begin(),v.display_values.end(),[&](const auto& x){return x.name==display_settings[i];});
        const bool ready=it!=v.display_values.end()&&it->available;
        ImGui::TextUnformatted(titles[i]);ImGui::BeginDisabled(!ready);
        if(i==0){bool enabled=ready&&(it->value=="true"||it->value=="1");
            if(ImGui::Checkbox("Enabled",&enabled))display_request({DisplayKind::Setting,display_settings[i],enabled?"true":"false"});
        }else{
            if(ready&&!initialized[i]){draft[i]=static_cast<float>(std::atof(it->value.c_str()));initialized[i]=true;}
            ImGui::SetNextItemWidth(240);ImGui::SliderFloat("##distance",&draft[i],1,10000,"%.0f",ImGuiSliderFlags_Logarithmic|ImGuiSliderFlags_AlwaysClamp);ImGui::SameLine();
            if(ImGui::Button("Apply"))display_request({DisplayKind::Setting,display_settings[i],std::to_string(draft[i])});
        }
        ImGui::SameLine();if(ImGui::SmallButton("Restore"))display_request({DisplayKind::Setting,display_settings[i],"",{},true});
        ImGui::EndDisabled();ImGui::TextDisabled("Live: %s",ready?it->value.c_str():"Waiting for engine setting");ImGui::PopID();
    }
    ImGui::TextWrapped("Distances use the engine's native values and apply to different object categories. Lower values can cause visible pop-in. Shadow maps do not cover every source of shading. Changes are session-only; Restore returns to the value before this trainer changed it.");
    ImGui::TextWrapped("%s",v.display_status.c_str());
    if(ImGui::CollapsingHeader("Planned performance controls"))ImGui::TextWrapped("Anti-aliasing modes, sharpness, pedestrian / traffic controls and a calibrated overall render-distance multiplier.");
}
void planned(int tab,const View& v,const overlay::Model& m){
    if(tab==2){label("LOBBY","Planned for a later build");ImGui::Text("Session: %s",v.offline?"Solo":m.multiplayer.hosting?"Hosting":"Guest");
        ImGui::TextWrapped("Player list with distance and ping; Teleport to Player; Spectate; host permissions; shared session controls and reset.");}
    ImGui::Spacing();ImGui::TextDisabled("Planned features have no active switches in this release.");
}
void info(const View& v){
    label("PARTVISION'S RESKATE TRAINER");
    ImGui::TextWrapped("Created for Partvision. Menu and integration developed with OpenAI Codex. Built on ReSkate by Dingo-Shenanigans, using Dear ImGui. Physics access and off-board velocity helpers are adapted from Andrew Nakas's ReSkate Trainer. GPL-3.0; source is included in the package.");
    ImGui::Spacing();ImGui::TextDisabled("Socials: not configured");ImGui::TextDisabled("Version: %s | ReSkate 1.0.6 | game build 25414733",version);
    if(ImGui::CollapsingHeader("Movement debug",ImGuiTreeNodeFlags_DefaultOpen)){
        ImGui::Text("Position X %.3f  Y %.3f  Z %.3f",v.position[0],v.position[1],v.position[2]);
        ImGui::Text("Speed X %.3f  Y %.3f  Z %.3f m/s",v.velocity[0],v.velocity[1],v.velocity[2]);
        ImGui::Text("Horizontal %.3f m/s | physics state %u",v.horizontal,v.physics_state);
        ImGui::Text("Completed jumps %llu",static_cast<unsigned long long>(v.jump_count));
        ImGui::TextWrapped("Velocity and airtime use wall-clock samples, so slow motion lowers the speed readings. Peak jump height is measured from positions. Teleports, respawns and long frame gaps reset the current sample.");
    }
    ImGui::TextWrapped("Settings: %%LOCALAPPDATA%%\\ReSkate\\PartvisionTrainer\\settings.json. Player values and bindings persist; player activation switches start off each launch. Visual settings use ReSkate preferences.");
    ImGui::TextWrapped("%s",v.storage_status.c_str());
}
}
#ifdef PARTVISION_UI_TEST
void test_select_tab(int tab){selected_tab=tab;}
#endif
void draw(bool& visible,const overlay::Model& model){
    int& tab=selected_tab;auto c=config();const auto v=view();
    auto& io=ImGui::GetIO();const auto previous_font=io.FontGlobalScale;const auto previous_style=ImGui::GetStyle();
    io.FontGlobalScale=c.ui_scale;ImGui::GetStyle().ScaleAllSizes(c.ui_scale);
    const ImVec2 maximum(std::max(320.0f,io.DisplaySize.x-24),std::max(240.0f,io.DisplaySize.y-24));
    static float last_scale=0;const bool resized=last_scale!=c.ui_scale;last_scale=c.ui_scale;
    ImGui::SetNextWindowSize(ImVec2(std::min(920*c.ui_scale,maximum.x),std::min(690*c.ui_scale,maximum.y)),resized?ImGuiCond_Always:ImGuiCond_FirstUseEver);
    ImGui::SetNextWindowPos(ImVec2(12,12),resized?ImGuiCond_Always:ImGuiCond_FirstUseEver);
    ImGui::SetNextWindowSizeConstraints(ImVec2(std::min(700*c.ui_scale,maximum.x),std::min(440*c.ui_scale,maximum.y)),maximum);
    ImGui::PushStyleVar(ImGuiStyleVar_WindowPadding,ImVec2(18*c.ui_scale,18*c.ui_scale));ImGui::PushStyleVar(ImGuiStyleVar_WindowRounding,8);ImGui::PushStyleVar(ImGuiStyleVar_FrameRounding,4);
    ImGui::PushStyleColor(ImGuiCol_WindowBg,ImVec4(0.045f,0.055f,0.075f,0.98f));ImGui::PushStyleColor(ImGuiCol_SliderGrab,ImVec4(0.3f,0.7f,1,1));
    if(ImGui::Begin("Partvision's ReSkate Trainer##partvision",&visible,ImGuiWindowFlags_NoCollapse)){
        ImGui::TextDisabled("%s  |  %s closes menu  |  %s resets overrides",version,key_name(c.binds[Menu].key).c_str(),key_name(c.binds[Reset].key).c_str());
        if(ImGui::Button("Reset all active overrides"))emergency_reset();
        ImGui::Separator();
        ImGui::BeginChild("navigation",ImVec2(132*c.ui_scale,0),ImGuiChildFlags_Borders);
        constexpr const char* tabs[]{"Home","Player","Lobby","Visual","Performance","Info"};
        for(int i=0;i<6;++i){if(ImGui::Selectable(tabs[i],tab==i,0,ImVec2(0,34*c.ui_scale)))tab=i;}
        ImGui::EndChild();ImGui::SameLine();
        ImGui::BeginChild("page",ImVec2(0,0));
        if(tab==0)home(v,model,c);else if(tab==1)player(v,c);else if(tab==3)visual(v,model);else if(tab==4)performance(v);else if(tab==5)info(v);else planned(tab,v,model);
        ImGui::Spacing();ImGui::Separator();keybinds(c);
        if(!feedback.empty())ImGui::TextWrapped("%s",feedback.c_str());
        ImGui::EndChild();
    }
    display_observe(visible&&(tab==3||tab==4));
    set_text_editing(recording>=0||ImGui::GetIO().WantTextInput);
    ImGui::End();ImGui::PopStyleColor(2);ImGui::PopStyleVar(3);io.FontGlobalScale=previous_font;ImGui::GetStyle()=previous_style;
}
}

