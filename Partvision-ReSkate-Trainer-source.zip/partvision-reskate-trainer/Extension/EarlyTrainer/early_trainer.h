#pragma once
#include "Extension/UI/Overlay/overlay.h"
#include <array>
#include <cstdint>
#include <string>
#include <string_view>
namespace dingosdk::early_trainer {
inline constexpr char version[]="0.4.0-preview6";
enum Action : int { Ollie, Slow, Boost, Noclip, Jump, NoFall, Reset, Menu, ActionCount };
inline constexpr std::array<const char*,ActionCount> action_names{"Ollie Power","Slow motion","Speed boost","Noclip / Fly","Off-board jump","Force No Fall","Emergency reset","Trainer menu"};
inline constexpr int PlayerActionCount=Reset;
struct Binding { int key=0; bool hold=false; };
enum Tweak:int {FootSpeed,FootHeight,InfiniteFoot,MultipleFlips,FlipSpeed,SpinSpeed,TweakCount};
inline constexpr std::array<const char*,TweakCount> tweak_names{"Footplant Speed (ground)","Footplant Height (ground)","Infinite Footplanting (experimental)","Allow Multiple Body Flips","Body Flip Speed","Body Spin Speed"};
enum Movement:int {OffSpeed,AirControl,Gravity,MovementCount};
inline constexpr std::array<const char*,MovementCount> movement_names{"Off-board Speed","Air Control","Gravity Multiplier"};
struct Config {
    float ollie=2, slow=0.5f, boost=10, speed_cap=35, flight=15, jump=1.5f;
    float ui_scale=1, slingshot_forward=20, slingshot_up=10;
    std::array<float,TweakCount> tweaks{1.5f,1.5f,1,1,1.5f,1.5f};
    std::array<Binding,TweakCount> tweak_binds{};
    std::array<float,MovementCount> movement{2,10,0.5f};
    std::array<Binding,MovementCount> movement_binds{};
    std::array<Binding,ActionCount> binds{{{0x75,false},{0x76,true},{0x77,true},{0x78,false},{0x79,false},{0,false},{0x23,false},{0x24,false}}};
};
struct Preset { std::string name; Config config; };
struct View {
    bool ready=false, offline=true, tuning_available=false;
    float applied=1, time_scale=1, fps=0, frame_ms=0;
    std::array<float,3> position{}, velocity{};
    bool telemetry_valid=false, airborne=false;
    float horizontal=0, air_time=0, height=0, last_height=0, last_air_time=0;
    std::uint32_t physics_state=0;
    std::uint64_t jump_count=0, offboard_boosts=0;
    std::string map, status="Load a map to begin.", time_status="Default", jump_status="Experimental: disabled", storage_status;
    std::vector<NamedSettingModel> display_values;
    std::string display_status;
    overlay::DebugModel debug;
    std::array<bool,PlayerActionCount> active{};
    bool no_fall_applied=false, no_fall_tuning=false;
    std::array<bool,MovementCount> movement_active{},movement_applied{};
    bool movement_available=false,offboard_jump_applied=false;
    std::array<std::string,MovementCount> movement_detail{};
    std::uint64_t movement_steps=0,movement_targets=0;float movement_gravity=0;std::array<float,2> movement_input{};
    std::string movement_status="Waiting for local physics";
    std::array<bool,TweakCount> tweak_active{},tweak_available{},tweak_applied{};
};
enum class DisplayKind { Graphics, Setting, Debug };
struct DisplayRequest { DisplayKind kind; std::string key, value; overlay::DebugRequest debug{}; bool restore=false; };
void display_request(DisplayRequest request);
void display_observe(bool wanted);
inline constexpr std::array<const char*,6> display_settings{
    "WorldRender.ShadowmapsEnable", "WorldRender.DetailCullDistance", "WorldRender.ShortCullDistance",
    "WorldRender.MediumCullDistance", "WorldRender.LongCullDistance", "WorldRender.ExtraLongCullDistance"};
Config config();
bool set_config(Config value, std::string& error);
std::array<Preset,3> presets();
void save_preset(int slot, const std::string& name);
void load_preset(int slot);
void set_active(Action action, bool enabled);
bool is_active(Action action);
void emergency_reset();
void boost_once();
void slingshot_once();
void set_tweak(Tweak feature,bool enabled);
bool tweak_enabled(Tweak feature);
void set_movement(Movement feature,bool enabled);
bool movement_enabled(Movement feature);
View view();
unsigned menu_key();
void set_text_editing(bool value);
std::string key_name(int vk);
void observe_debug(const overlay::DebugModel& debug);
void note_present();
void tick(std::uintptr_t base, std::uintptr_t client, bool ready, bool offline, std::string_view map) noexcept;
void draw(bool& visible, const overlay::Model& model);
}
