#include "Extension/EarlyTrainer/early_trainer.h"
#include <imgui.h>
#include "trainer_logic.h"
#include <iostream>
#include <fstream>
#include <filesystem>
namespace dingosdk::early_trainer {
Config ui_config;
Config config(){return ui_config;}
bool set_config(Config value,std::string& error){if(!normalize(value,error))return false;ui_config=value;return true;}
std::array<Preset,3> presets(){return {};}
void save_preset(int,const std::string&){}
void load_preset(int){}
bool available=true;
View view(){View v;v.ready=available;v.offline=available;v.tuning_available=available;v.telemetry_valid=available;v.fps=144;v.frame_ms=6.94f;v.map="Test map";v.status="Ready";v.debug.camera_available=available;v.debug.no_bail_available=available;v.tweak_available.fill(available);v.movement_available=available;v.movement_status=available?"Ready":"Waiting for local physics";for(const auto* name:display_settings){NamedSettingModel m;m.name=name;m.available=available;m.value="100";v.display_values.push_back(m);}return v;}
void set_active(Action,bool){}
bool is_active(Action){return false;}
void display_request(DisplayRequest){}
void display_observe(bool){}
void emergency_reset(){}
void boost_once(){}
void slingshot_once(){}
void set_tweak(Tweak,bool){}
bool tweak_enabled(Tweak){return false;}
void set_movement(Movement,bool){}
bool movement_enabled(Movement){return false;}
void set_text_editing(bool){}
std::string key_name(int key){if(!key)return "Unbound";if(key==0x24)return "Home";if(key==0x23)return "End";if(key>=0x70&&key<=0x87)return "F"+std::to_string(key-0x6f);return "Key";}
void test_select_tab(int);
void test_select_player_tab(int);
ImVec2 test_numeric_slider(Config&);
}

void export_frame(const std::filesystem::path& path) {
    auto* draw=ImGui::GetDrawData();unsigned char* pixels=nullptr;int width=0,height=0;
    ImGui::GetIO().Fonts->GetTexDataAsRGBA32(&pixels,&width,&height);
    std::ofstream f(path,std::ios::binary);
    f.write(reinterpret_cast<const char*>(&width),4);f.write(reinterpret_cast<const char*>(&height),4);
    f.write(reinterpret_cast<const char*>(pixels),static_cast<std::streamsize>(width)*height*4);
    for(int list=0;list<draw->CmdListsCount;++list){const auto* l=draw->CmdLists[list];
        for(const auto& cmd:l->CmdBuffer){if(cmd.UserCallback)continue;
            for(unsigned idx=0;idx+2<cmd.ElemCount;idx+=3){f.write(reinterpret_cast<const char*>(&cmd.ClipRect),16);
                for(unsigned k=0;k<3;++k){const auto& v=l->VtxBuffer[l->IdxBuffer[cmd.IdxOffset+idx+k]+cmd.VtxOffset];f.write(reinterpret_cast<const char*>(&v),sizeof(v));}
            }
        }
    }
}
int main(int argc,char** argv){
    ImGui::CreateContext();auto& io=ImGui::GetIO();io.IniFilename=nullptr;io.DisplaySize=ImVec2(1280,900);io.DeltaTime=1.0f/60;
    io.Fonts->AddFontFromFileTTF("C:/Windows/Fonts/arial.ttf",17);
    unsigned char* pixels=nullptr;int width=0,height=0;io.Fonts->GetTexDataAsRGBA32(&pixels,&width,&height);
    bool visible=true;dingosdk::overlay::Model model;
    for(float scale:{0.75f,1.0f,1.5f})for(int state=0;state<2;++state)for(int page=0;page<6;++page){
        dingosdk::early_trainer::ui_config.ui_scale=scale;
        model.graphics.available=state==0;dingosdk::early_trainer::available=state==0;dingosdk::early_trainer::test_select_tab(page);
        for(int frame=0;frame<3;++frame){ImGui::NewFrame();dingosdk::early_trainer::draw(visible,model);ImGui::Render();}
        if(argc>1 && state==0 && (page==0||page==1)&&scale==1)export_frame(std::filesystem::path(argv[1])/(page==0?"home.bin":"player.bin"));
        if(!visible||ImGui::GetDrawData()->TotalVtxCount<=0){std::cerr<<"UI failure at page "<<page;return 1;}
    }
    for(float scale:{0.75f,1.0f,1.5f})for(int state=0;state<2;++state)for(int page=0;page<4;++page){
        dingosdk::early_trainer::ui_config.ui_scale=scale;dingosdk::early_trainer::available=state==0;
        dingosdk::early_trainer::test_select_tab(1);dingosdk::early_trainer::test_select_player_tab(page);
        for(int frame=0;frame<3;++frame){ImGui::NewFrame();dingosdk::early_trainer::draw(visible,model);ImGui::Render();}
        if(argc>1&&state==0&&scale==1)export_frame(std::filesystem::path(argv[1])/("player"+std::to_string(page)+".bin"));
        if(ImGui::GetDrawData()->TotalVtxCount<=0)return 1;
    }
    // Exercise the actual right-click, text-input and Enter path rather than calling its callback.
    dingosdk::early_trainer::ui_config=dingosdk::early_trainer::Config{};
    const auto numeric_frame=[&](){ImGui::NewFrame();ImGui::SetNextWindowPos(ImVec2(20,20));ImGui::SetNextWindowSize(ImVec2(600,250));ImGui::Begin("Numeric test");auto c=dingosdk::early_trainer::ui_config;const auto pos=dingosdk::early_trainer::test_numeric_slider(c);ImGui::End();ImGui::Render();return pos;};
    auto pos=numeric_frame();numeric_frame();io.AddMousePosEvent(pos.x,pos.y);numeric_frame();
    io.AddMouseButtonEvent(1,true);numeric_frame();io.AddMouseButtonEvent(1,false);numeric_frame();numeric_frame();
    io.AddKeyEvent(ImGuiMod_Ctrl,true);io.AddKeyEvent(ImGuiKey_A,true);numeric_frame();
    io.AddKeyEvent(ImGuiKey_A,false);io.AddKeyEvent(ImGuiMod_Ctrl,false);io.AddInputCharactersUTF8("12.5");numeric_frame();numeric_frame();
    if(argc>1)export_frame(std::filesystem::path(argv[1])/"numeric.bin");
    io.AddKeyEvent(ImGuiKey_Enter,true);numeric_frame();io.AddKeyEvent(ImGuiKey_Enter,false);numeric_frame();
    if(dingosdk::early_trainer::ui_config.tweaks[dingosdk::early_trainer::FootSpeed]!=12.5f){std::cerr<<"Right-click custom number failed";return 1;}
    numeric_frame();if(dingosdk::early_trainer::ui_config.tweaks[dingosdk::early_trainer::FootSpeed]!=12.5f){std::cerr<<"Slider clamped custom number on redraw";return 1;}
    // An invalid draft must neither change the setting nor close the popup; Escape cancels it.
    io.AddMousePosEvent(pos.x,pos.y);numeric_frame();io.AddMouseButtonEvent(1,true);numeric_frame();io.AddMouseButtonEvent(1,false);numeric_frame();numeric_frame();
    io.AddKeyEvent(ImGuiMod_Ctrl,true);io.AddKeyEvent(ImGuiKey_A,true);numeric_frame();io.AddKeyEvent(ImGuiKey_A,false);io.AddKeyEvent(ImGuiMod_Ctrl,false);io.AddInputCharactersUTF8("1001");numeric_frame();numeric_frame();
    io.AddKeyEvent(ImGuiKey_Enter,true);numeric_frame();io.AddKeyEvent(ImGuiKey_Enter,false);numeric_frame();
    if(dingosdk::early_trainer::ui_config.tweaks[dingosdk::early_trainer::FootSpeed]!=12.5f){std::cerr<<"Invalid draft committed";return 1;}
    io.AddKeyEvent(ImGuiKey_Escape,true);numeric_frame();io.AddKeyEvent(ImGuiKey_Escape,false);numeric_frame();
    if(dingosdk::early_trainer::ui_config.tweaks[dingosdk::early_trainer::FootSpeed]!=12.5f){std::cerr<<"Cancel changed setting";return 1;}
    ImGui::DestroyContext();std::cout<<"PASS: all six tabs and four Player pages render in ready and unavailable states at 75%, 100%, 150% scale without ImGui assertions; right-click numeric entry commits 12.5x and retains it on redraw.\n";
}
