#include "trick_model.h"
#include <iostream>
#include <limits>
int main(int argc, char** argv) {
    if (argc < 2) return 2;
    try {
        using namespace dingosdk::early_trainer;
        const auto m = dingosdk::physics_tuning::read_game_tuning(argv[1]);
        if(argc>2){for(std::size_t i=0;i<m.fields.size();++i){const auto& f=m.fields[i];const auto& n=m.field_names[i];if(n.find("Footplant")!=std::string::npos||n.find("Gravity")!=std::string::npos||n.find("Flip")!=std::string::npos||n.find("Spin")!=std::string::npos||n.starts_with("PhysicsBodyspin.")||n.find("Offboard")!=std::string::npos||n.find("Air")!=std::string::npos){std::cout<<f.offset<<" | "<<n<<" | ";if(f.real){float v;std::memcpy(&v,m.image.data()+f.offset,4);std::cout<<v;}else if(f.flag)std::cout<<int(m.image[f.offset]);else std::cout<<"integer";std::cout<<'\n';}}return 0;}
        const auto map=trick_map(m);
        std::size_t total=0;std::array<TrickLease,TweakCount+1> leases;
        auto live=m.image;auto target=live;
        for(std::size_t group=0;group<map.size();++group){
            if(map[group].empty())throw std::runtime_error("Missing feature mapping "+std::to_string(group));
            total+=map[group].size();leases[group].compose(target,live,map[group],true,2);
        }
        for(std::size_t i=0;i<target.size();++i){bool owned=false;for(const auto& group:map)for(auto f:group)owned=owned||(i>=f.offset&&i<std::size_t(f.offset)+(f.flag?1:4));
            if(!owned&&target[i]!=live[i])throw std::runtime_error("Unrelated field modified");}
        const auto boosted=target;
        // Turn off one feature while other feature values remain applied.
        leases[FootSpeed+1].compose(target,target,map[FootSpeed+1],false,1);leases[FootSpeed+1].completed(false);
        for(auto f:map[FootSpeed+1])if(std::memcmp(target.data()+f.offset,m.image.data()+f.offset,4))throw std::runtime_error("Individual reset failed");
        for(auto f:map[SpinSpeed+1])if(std::memcmp(target.data()+f.offset,boosted.data()+f.offset,4))throw std::runtime_error("Individual reset changed another feature");
        for(std::size_t group=0;group<map.size();++group){leases[group].compose(target,target,map[group],false,1);leases[group].completed(false);}
        if(target!=m.image)throw std::runtime_error("Full reset was not exact");
        // A new activation captures a freshly changed baseline, not the original game default.
        const auto f=map[FootSpeed+1].front();float custom=7;std::memcpy(target.data()+f.offset,&custom,4);const auto custom_image=target;
        leases[FootSpeed+1].compose(target,target,map[FootSpeed+1],true,2);
        leases[FootSpeed+1].compose(target,target,map[FootSpeed+1],false,1);leases[FootSpeed+1].completed(false);
        if(target!=custom_image)throw std::runtime_error("Fresh baseline was not restored");
        auto unsupported=m;unsupported.field_names[0]="Unknown";
        for(std::size_t i=0;i<unsupported.field_names.size();++i)if(unsupported.field_names[i]=="PhysicsFootplant.TakeOffVelUp")unsupported.field_names[i]="Unknown";
        if(!trick_map(unsupported)[FootHeight+1].empty())throw std::runtime_error("Unsupported feature enabled");
        std::cout<<"PASS: "<<total<<" mapped fields in seven feature groups; exact full and individual reset, unrelated-byte preservation, fresh baseline capture and unsupported-feature rejection.\n";
    } catch (const std::exception& e) { std::cerr << e.what(); return 1; }
}
