#include "trick_model.h"
#include <iostream>
#include <limits>
#include "Engine/Resource/ebx_document.h"
#include "Engine/Vfs/game_bundles.h"
int main(int argc, char** argv) {
    if (argc < 2) return 2;
    try {
        using namespace dingosdk::early_trainer;
        const auto m = dingosdk::physics_tuning::read_game_tuning(argv[1]);
        if(argc>2){
            const dingosdk::vfs::GameData data(argv[1]);
            const auto bundle=data.read_bundle(data.read_toc("Win32/levels/game/bam_levelroot/bam_levelroot.toc"),"win32/levels/game/bam_levelroot/bam_levelroot");
            for(std::size_t i=0;i<bundle->manifest.ebx.size();++i)if(bundle->manifest.ebx[i].name=="gameplay/skatephysicstuning"){
                const auto doc=dingosdk::frostbite::ebx::read_document(data.read(*bundle->payload(dingosdk::frostbite::AssetKind::ebx,i)));
                for(const auto& type:doc.types)if(type.name=="FloatCurvePoint")for(std::size_t k=0;k<type.fieldCount;++k){const auto& field=doc.fields[type.fieldIndex+k];std::cout<<"POINT "<<field.name<<" offset "<<field.dataOffset<<'\n';}
            }
            for(std::size_t i=0;i<m.curve_names.size();++i)if(m.curve_names[i].starts_with("PhysicsBoneless."))std::cout<<"CURVE "<<m.curve_names[i]<<" slot "<<m.curve_slots[i]<<" points "<<(m.curves[i]?m.curves[i]->points.size()/28:0)<<'\n';
            for(std::size_t i=0;i<m.fields.size();++i){const auto& f=m.fields[i];const auto& n=m.field_names[i];if(n.find("Footplant")!=std::string::npos||n.find("Boneless")!=std::string::npos||n.find("Fastplant")!=std::string::npos||n.find("FastPlant")!=std::string::npos||n.find("Gravity")!=std::string::npos||n.find("Flip")!=std::string::npos||n.find("Spin")!=std::string::npos||n.starts_with("PhysicsBodyspin.")||n.find("Offboard")!=std::string::npos||n.find("Air")!=std::string::npos){std::cout<<f.offset<<" | "<<n<<" | ";if(f.real){float v;std::memcpy(&v,m.image.data()+f.offset,4);std::cout<<v;}else if(f.flag)std::cout<<int(m.image[f.offset]);else std::cout<<"integer";std::cout<<'\n';}}return 0;}
        const auto map=trick_map(m);const auto curves=trick_curves(m);
        std::size_t total=0;std::array<TrickLease,TweakCount+1> leases;
        dingosdk::physics_tuning::Values live{m.image,m.curves};auto target=live;
        for(std::size_t group=0;group<map.size();++group){
            if(map[group].empty())throw std::runtime_error("Missing feature mapping "+std::to_string(group));
            total+=map[group].size();leases[group].compose(target,live,map[group],curves[group],true,2);
        }
        for(std::size_t i=0;i<target.image.size();++i){bool owned=false;for(const auto& group:map)for(auto f:group)owned=owned||(i>=f.offset&&i<std::size_t(f.offset)+(f.flag?1:4));
            if(!owned&&target.image[i]!=live.image[i])throw std::runtime_error("Unrelated field modified");}
        if(curves[FootSpeed+1].size()!=1)throw std::runtime_error("Ground fastplant speed curve not mapped");
        const auto speed_curve=curves[FootSpeed+1].front();
        const auto& original_curve=*m.curves[speed_curve];const auto& changed_curve=*target.curves[speed_curve];
        if(original_curve.min!=changed_curve.min||original_curve.max!=changed_curve.max)throw std::runtime_error("Curve domain modified");
        for(std::size_t point=0;point<original_curve.points.size();point+=28)for(std::size_t offset=0;offset<28;offset+=4){
            const bool ordinate=offset==4||offset==16||offset==20;
            if(ordinate){float before=0,after=0;std::memcpy(&before,original_curve.points.data()+point+offset,4);std::memcpy(&after,changed_curve.points.data()+point+offset,4);if(after!=before*2)throw std::runtime_error("Ground speed curve not scaled");}
            else if(std::memcmp(original_curve.points.data()+point+offset,changed_curve.points.data()+point+offset,4))throw std::runtime_error("Curve X or type modified");
        }
        for(std::size_t index=0;index<m.curves.size();++index)if(index!=speed_curve&&target.curves[index]!=m.curves[index])throw std::runtime_error("Unrelated curve changed");
        const auto boosted=target;
        // Turn off one feature while other feature values remain applied.
        leases[FootSpeed+1].compose(target,target,map[FootSpeed+1],curves[FootSpeed+1],false,1);leases[FootSpeed+1].completed(false);
        for(auto f:map[FootSpeed+1])if(std::memcmp(target.image.data()+f.offset,m.image.data()+f.offset,4))throw std::runtime_error("Individual reset failed");
        if(target.curves[speed_curve]!=m.curves[speed_curve])throw std::runtime_error("Individual curve reset failed");
        for(auto f:map[SpinSpeed+1])if(std::memcmp(target.image.data()+f.offset,boosted.image.data()+f.offset,4))throw std::runtime_error("Individual reset changed another feature");
        for(std::size_t group=0;group<map.size();++group){leases[group].compose(target,target,map[group],curves[group],false,1);leases[group].completed(false);}
        if(target.image!=m.image||target.curves!=m.curves)throw std::runtime_error("Full reset was not exact");
        // A new activation captures a freshly changed baseline, not the original game default.
        const auto f=map[FootSpeed+1].front();float custom=7;std::memcpy(target.image.data()+f.offset,&custom,4);std::memcpy(target.curves[speed_curve]->points.data()+20,&custom,4);const auto custom_image=target;
        leases[FootSpeed+1].compose(target,target,map[FootSpeed+1],curves[FootSpeed+1],true,2);
        leases[FootSpeed+1].compose(target,target,map[FootSpeed+1],curves[FootSpeed+1],false,1);leases[FootSpeed+1].completed(false);
        if(target.image!=custom_image.image||target.curves!=custom_image.curves)throw std::runtime_error("Fresh baseline was not restored");
        // Manual values beyond the slider ceiling reach both the inline graph and active curve.
        auto large=live;TrickLease manual;
        manual.compose(large,live,map[FootSpeed+1],curves[FootSpeed+1],true,12.5f);
        float before=0,after=0;std::memcpy(&before,m.image.data()+map[FootSpeed+1].front().offset,4);std::memcpy(&after,large.image.data()+map[FootSpeed+1].front().offset,4);
        if(after!=before*12.5f)throw std::runtime_error("Manual factor clamped to slider range");
        manual.compose(large,large,map[FootSpeed+1],curves[FootSpeed+1],false,1);
        if(large.image!=live.image||large.curves!=live.curves)throw std::runtime_error("Manual value reset failed");
        auto unsupported=m;unsupported.field_names[0]="Unknown";
        for(std::size_t i=0;i<unsupported.field_names.size();++i)if(unsupported.field_names[i]=="PhysicsBoneless.JumpHeightVsPlanarSpeed.Y0")unsupported.field_names[i]="Unknown";
        if(!trick_map(unsupported)[FootHeight+1].empty())throw std::runtime_error("Unsupported feature enabled");
        std::cout<<"PASS: "<<total<<" mapped fields and active ground-speed curve in seven feature groups; exact full and individual reset, unrelated-byte preservation, fresh baseline capture and unsupported-feature rejection.\n";
    } catch (const std::exception& e) { std::cerr << e.what(); return 1; }
}

