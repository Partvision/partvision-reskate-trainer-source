#include "ollie_model.h"
#include <iostream>
#include <limits>
int main(int argc, char** argv) {
    if (argc != 2) return 2;
    try {
        using namespace dingosdk::early_trainer;
        const auto m = dingosdk::physics_tuning::read_game_tuning(argv[1]);
        const auto fields=height_fields(m);
        auto target=m.image;
        scale_heights(target,m.image,fields,2);
        for (std::size_t i=0;i<target.size();++i) {
            bool changed=false;
            for (auto f:fields) if (i>=f && i<std::size_t(f)+4) changed=true;
            if (!changed && target[i]!=m.image[i]) throw std::runtime_error("Unrelated field changed.");
        }
        for (auto f:fields) {
            float before,after;
            std::memcpy(&before,m.image.data()+f,4); std::memcpy(&after,target.data()+f,4);
            if (after!=before*2) throw std::runtime_error("Height scaling failed.");
        }
        scale_heights(target,m.image,fields,1);
        if (target!=m.image) throw std::runtime_error("Reset failed.");
        if (bounded(std::numeric_limits<float>::quiet_NaN())!=1 || bounded(-1)!=0.25f || bounded(99)!=10)
            throw std::runtime_error("Input bounds failed.");
        auto bad=m; bad.field_names.clear();
        bool rejected=false;
        try { (void)height_fields(bad); } catch (...) { rejected=true; }
        if (!rejected) throw std::runtime_error("Unsupported schema accepted.");
        std::cout<<"PASS: "<<fields.size()<<" verified height graph fields; scaling, reset, unrelated-field preservation, bounds, unsupported-schema rejection.\n";
    } catch (const std::exception& e) { std::cerr << e.what(); return 1; }
}
