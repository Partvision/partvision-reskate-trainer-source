#pragma once
#include "early_trainer.h"
#include <algorithm>
#include <cmath>
#include <set>
namespace dingosdk::early_trainer {
inline float finite_clamp(float value,float low,float high,float fallback) {
    return std::isfinite(value)?std::clamp(value,low,high):fallback;
}
inline bool normalize(Config& c, std::string& error) {
    c.ollie=finite_clamp(c.ollie,0.25f,10,2); c.slow=finite_clamp(c.slow,0.1f,1,0.5f);
    c.boost=finite_clamp(c.boost,1,50,10); c.speed_cap=finite_clamp(c.speed_cap,5,150,35);
    c.flight=finite_clamp(c.flight,0.6f,300,15); c.jump=finite_clamp(c.jump,0.25f,5,1.5f);
    std::set<int> used;
    for(int i=0;i<ActionCount;++i) {
        const int key=c.binds[i].key;
        if(key==0 && i!=Menu && i!=Reset) continue;
        if(key<8 || key>254 || key==0x1b || key==0x2d || key==0xc0 || key==0x0d || key==0x09 ||
           key==0x10 || key==0x11 || key==0x12 || key=='W' || key=='A' || key=='S' || key=='D' || key=='Q' || key=='E' || key=='T') {
            error="That key is reserved for menus, chat or flight controls."; return false;
        }
        if(!used.insert(key).second) {error="That key is already assigned to a trainer action.";return false;}
    }
    c.binds[Reset].hold=false;c.binds[Menu].hold=false; error.clear();return true;
}
struct KeyLatch {
    bool down=false, blocked_until_release=false;
    bool press(bool raw,bool allowed) {
        if(!allowed) { blocked_until_release=raw;down=raw;return false; }
        if(!raw) blocked_until_release=false;
        const bool edge=raw&&!down&&!blocked_until_release;down=raw;return edge;
    }
    bool held(bool raw,bool allowed) const {return raw&&allowed&&!blocked_until_release;}
};
struct Motion {
    bool valid=false, airborne=false, jump_armed=false;
    std::array<float,3> position{}, velocity{};
    std::uintptr_t entity=0;
    double stamp=0, takeoff_time=0, grounded_time=0;
    float takeoff_y=0, apex=0, last_height=0, last_air=0;
    unsigned last_state=0;
    std::uint64_t count=0;
    // Wall-clock velocities, explicitly labelled by the UI; jump height is time-scale independent.
    bool sample(std::array<float,3> p,double now,std::uintptr_t who,unsigned state,bool flying,bool reset) {
        float distance=0;for(int i=0;i<3;++i)distance+=(p[i]-position[i])*(p[i]-position[i]);
        const double dt=now-stamp;
        if(reset||!valid||entity!=who||dt<=0||dt>0.25||distance>625) {
            valid=!reset;airborne=false;jump_armed=false;grounded_time=0;
            position=p;velocity={};stamp=now;entity=who;last_state=state;return false;
        }
        for(int i=0;i<3;++i) velocity[i]=(p[i]-position[i])/static_cast<float>(dt);
        bool trigger=false;
        if(state==504 && last_state==504 && !flying) {
            if(std::abs(velocity[1])<0.35f) {grounded_time+=dt;if(grounded_time>0.25)jump_armed=true;}
            else grounded_time=0;
            if(jump_armed && velocity[1]>1.0f) {trigger=true;jump_armed=false;}
        } else {grounded_time=0;jump_armed=false;}
        const bool air=state>=200&&state<300&&!flying;
        if(air&&!airborne){takeoff_y=position[1];apex=std::max(p[1],position[1]);takeoff_time=stamp;}
        if(airborne||air)apex=std::max(apex,p[1]);
        if(airborne&&!air){last_height=std::max(0.0f,apex-takeoff_y);last_air=static_cast<float>(now-takeoff_time);++count;}
        airborne=air;position=p;stamp=now;last_state=state;return trigger;
    }
};
}
