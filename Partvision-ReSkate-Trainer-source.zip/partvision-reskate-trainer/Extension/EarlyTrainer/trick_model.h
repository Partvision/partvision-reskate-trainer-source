#pragma once
#include "ollie_model.h"
#include "early_trainer.h"
namespace dingosdk::early_trainer {
struct TrickField {std::uint16_t offset{};bool flag{};float override_value=-1;};
using TrickMap=std::array<std::vector<TrickField>,TweakCount+1>;
inline TrickMap trick_map(const physics_tuning::Model& m){
    TrickMap result;
    for(auto offset:height_fields(m))result[0].push_back({offset,false,-1});
    const auto scalar=[&](int group,std::string_view name,bool flag=false,float value=-1){
        for(std::size_t i=0;i<m.fields.size();++i)if(m.field_names[i]==name){const auto& f=m.fields[i];
            if((flag&&f.flag&&f.size==1)||(!flag&&f.real&&f.size==4))result[group].push_back({f.offset,flag,value});return;}
    };
    scalar(FootSpeed+1,"PhysicsFootplant.JumpAdjustStandstillLaunchSpeed");
    scalar(FootSpeed+1,"PhysicsFootplant.JumpAdjustMaxLaunchSpeed");
    scalar(FootHeight+1,"PhysicsFootplant.TakeOffVelUp");
    scalar(InfiniteFoot+1,"PhysicsFootplant.PopHeightDecayMultiplier",false,1);
    scalar(MultipleFlips+1,"PhysicsMode.PerfectBodyFlips",true,0);
    scalar(FlipSpeed+1,"PhysicsReckoning.FlipScalar");scalar(FlipSpeed+1,"PhysicsReckoning.FlipMaxSpeed");
    scalar(SpinSpeed+1,"PhysicsMode.MaxAutoBodySpinSpeed");
    for(const std::string prefix:{"PhysicsBodyspin.PropBodySpinVsTime.","PhysicsBodyspin.PBSVsT_Easy.","PhysicsBodyspin.MaxDeltaVsTime.","PhysicsBodyspin.MaxDeltaVsTimeEasy."}){
        std::vector<TrickField> graph;
        for(std::size_t i=0;i<m.fields.size();++i){const auto& f=m.fields[i];const auto& name=m.field_names[i];
            if(!f.real||f.size!=4||!name.starts_with(prefix))continue;const auto leaf=name.substr(prefix.size());
            bool y=leaf=="Min_Y"||leaf=="Max_Y";for(int k=0;k<16;++k)y=y||leaf=="Y"+std::to_string(k);
            if(y)graph.push_back({f.offset,false,-1});}
        if(graph.size()!=18){result[SpinSpeed+1].clear();break;}
        result[SpinSpeed+1].insert(result[SpinSpeed+1].end(),graph.begin(),graph.end());
    }
    constexpr std::array<std::size_t,TweakCount+1> sizes{36,2,1,1,1,2,73};
    for(std::size_t i=0;i<result.size();++i)if(result[i].size()!=sizes[i])result[i].clear();
    return result;
}
struct TrickLease {
    std::vector<std::uint8_t> original;
    bool owned=false;
    // target begins as a copy of live; unrelated values and curve pointers stay untouched.
    void compose(std::vector<std::uint8_t>& target,const std::vector<std::uint8_t>& live,
        const std::vector<TrickField>& fields,bool enabled,float factor){
        if(fields.empty())return;
        if(enabled&&!owned){original=live;owned=true;}
        if(!owned)return;
        for(const auto& f:fields){const auto size=f.flag?1u:4u;
            if(std::size_t(f.offset)+size>target.size()||std::size_t(f.offset)+size>original.size())throw std::runtime_error("Trick field outside asset");
            if(!enabled){std::memcpy(target.data()+f.offset,original.data()+f.offset,size);continue;}
            if(f.flag){target[f.offset]=static_cast<std::uint8_t>(f.override_value);continue;}
            float value=0;std::memcpy(&value,original.data()+f.offset,4);
            value=f.override_value>=0?f.override_value:value*factor;
            if(!std::isfinite(value))throw std::runtime_error("Invalid trick tuning value");
            std::memcpy(target.data()+f.offset,&value,4);
        }
    }
    void completed(bool enabled){if(!enabled){original.clear();owned=false;}}
};
}
