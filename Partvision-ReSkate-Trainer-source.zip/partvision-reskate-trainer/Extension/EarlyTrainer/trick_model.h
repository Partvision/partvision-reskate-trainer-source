#pragma once
#include "ollie_model.h"
#include "early_trainer.h"
namespace dingosdk::early_trainer {
struct TrickField {std::uint16_t offset{};bool flag{};float override_value=-1;};
inline constexpr int NoFallGroup=TweakCount+1, TrickGroupCount=TweakCount+2;
using TrickMap=std::array<std::vector<TrickField>,TrickGroupCount>;
inline TrickMap trick_map(const physics_tuning::Model& m){
    TrickMap result;
    for(auto offset:height_fields(m))result[0].push_back({offset,false,-1});
    const auto scalar=[&](int group,std::string_view name,bool flag=false,float value=-1){
        for(std::size_t i=0;i<m.fields.size();++i)if(m.field_names[i]==name){const auto& f=m.fields[i];
            if((flag&&f.flag&&f.size==1)||(!flag&&f.real&&f.size==4))result[group].push_back({f.offset,flag,value});return;}
    };
    const auto collect_graph=[&](int group,std::string_view prefix){
        std::vector<TrickField> fields;
        for(std::size_t i=0;i<m.fields.size();++i){const auto& f=m.fields[i];const auto& name=m.field_names[i];
            if(!f.real||f.size!=4||!name.starts_with(prefix))continue;const auto leaf=name.substr(prefix.size());
            bool y=leaf=="Min_Y"||leaf=="Max_Y";for(int k=0;k<16;++k)y=y||leaf=="Y"+std::to_string(k);
            if(y)fields.push_back({f.offset,false,-1});}
        if(fields.size()==18)result[group].insert(result[group].end(),fields.begin(),fields.end());
    };
    // Ground fastplant launch passes these two graphs to 0x48153d0 in build 25414733.
    collect_graph(FootSpeed+1,"PhysicsBoneless.JumpPlanarVsPlanarSpeed.");
    collect_graph(FootHeight+1,"PhysicsBoneless.JumpHeightVsPlanarSpeed.");
    scalar(InfiniteFoot+1,"PhysicsFootplant.PopHeightDecayMultiplier",false,1);
    scalar(MultipleFlips+1,"PhysicsMode.PerfectBodyFlips",true,0);
    scalar(FlipSpeed+1,"PhysicsReckoning.FlipScalar");scalar(FlipSpeed+1,"PhysicsReckoning.FlipMaxSpeed");
    scalar(SpinSpeed+1,"PhysicsMode.MaxAutoBodySpinSpeed");
    for(const std::string prefix:{"PhysicsBodyspin.PropBodySpinVsTime.","PhysicsBodyspin.PBSVsT_Easy.","PhysicsBodyspin.MaxDeltaVsTime.","PhysicsBodyspin.MaxDeltaVsTimeEasy."}){
        std::vector<TrickField> graph;
        for(std::size_t i=0;i<m.fields.size();++i){const auto& f=m.fields[i];const auto& name=m.field_names[i];
            if(!f.real||f.size!=4||!name.starts_with(prefix))continue;const auto leaf=name.substr(prefix.size());
            bool y=leaf=="Min_Y"||leaf=="Max_Y";for(int k=0;k<16;++k)y=y||leaf=="Y"+std::to_string(k);
            if(y)graph.push_back({f.offset,false,-1});}
        if(graph.size()!=18){result[SpinSpeed+1].clear();break;}
        result[SpinSpeed+1].insert(result[SpinSpeed+1].end(),graph.begin(),graph.end());
    }
    // Prevent bad/upside-down/squashed landings before they generate a bail request.
    for(const char* name:{"PhysicsMode.WipeoutCheckForSquashedSkeleton","PhysicsMode.WipeoutCheckForBadLanding","PhysicsMode.Wipeout_UpsideDown","PhysicsMode.NoseManualBrakeTriggersBail"})scalar(NoFallGroup,name,true,0);
    for(const char* name:{"PhysicsMode.Wipeout_GroundXZAcceleration","PhysicsMode.Wipeout_GroundHighYAcceleration","PhysicsMode.Wipeout_GroundHighXZAcceleration",
        "PhysicsWipeout.Wipeout_AirYAcceleration","PhysicsWipeout.Wipeout_AirXZAcceleration","PhysicsWipeout.Wipeout_AirMaxSpeedIntoGround","PhysicsWipeout.Wipeout_AirMaxSpeedIntoStairs",
        "PhysicsWipeout.Wipeout_AirMaxSpeedIntoCollisionNearGrind","PhysicsWipeout.Wipeout_AirTrick_MaxYContactForce","PhysicsWipeout.Wipeout_AirTrick_MaxXZContactForce",
        "PhysicsFootplant.WipeoutMaxLandingSpeedDown","PhysicsFootplant.WipeoutMaxLandingSpeedHoriz"})scalar(NoFallGroup,name,false,1000000);
    for(const char* part:{"Leg","Arm","Head","Torso","Foot"})for(const char* kind:{"OnBoardInAirWipeoutForceLimits.","OnBoardOnGroundWipeoutForceLimits."})scalar(NoFallGroup,std::string("SkatePhysicsWipeout.")+kind+part,false,1000000);
    constexpr std::array<std::size_t,TrickGroupCount> sizes{36,18,18,1,1,2,73,26};
    for(std::size_t i=0;i<result.size();++i)if(result[i].size()!=sizes[i])result[i].clear();
    return result;
}
using TrickCurves=std::array<std::vector<std::size_t>,TrickGroupCount>;
inline TrickCurves trick_curves(const physics_tuning::Model& m){
    TrickCurves result;
    for(std::size_t i=0;i<m.curve_names.size();++i){
        if(m.curve_names[i]=="PhysicsBoneless.JumpPlanarVsPlanarSpeed.Curve")result[FootSpeed+1].push_back(i);
        if(m.curve_names[i]=="PhysicsBoneless.JumpHeightVsPlanarSpeed.Curve")result[FootHeight+1].push_back(i);
    }
    return result;
}
struct TrickLease {
    physics_tuning::Values original;
    bool owned=false;
    // target begins as live. Only the feature's fields and curve ordinates change.
    void compose(physics_tuning::Values& target,const physics_tuning::Values& live,
        const std::vector<TrickField>& fields,const std::vector<std::size_t>& curves,bool enabled,float factor){
        if(fields.empty())return;
        if(enabled&&!owned){original=live;owned=true;}
        if(!owned)return;
        for(const auto& f:fields){const auto size=f.flag?1u:4u;
            if(std::size_t(f.offset)+size>target.image.size()||std::size_t(f.offset)+size>original.image.size())throw std::runtime_error("Trick field outside asset");
            if(!enabled){std::memcpy(target.image.data()+f.offset,original.image.data()+f.offset,size);continue;}
            if(f.flag){target.image[f.offset]=static_cast<std::uint8_t>(f.override_value);continue;}
            float value=0;std::memcpy(&value,original.image.data()+f.offset,4);
            value=f.override_value>=0?f.override_value:value*factor;
            if(!std::isfinite(value))throw std::runtime_error("Invalid trick tuning value");
            std::memcpy(target.image.data()+f.offset,&value,4);
        }
        for(auto index:curves){
            if(index>=target.curves.size()||index>=original.curves.size())throw std::runtime_error("Trick curve outside asset");
            if(!original.curves[index])continue;
            auto curve=*original.curves[index];
            if(curve.points.size()%28)throw std::runtime_error("Unsupported trick curve layout");
            // EBX FloatCurvePoint: ordinate +20; tangent Y offsets +4/+16. Domain and tangent X stay unchanged.
            if(enabled)for(std::size_t point=0;point<curve.points.size();point+=28)for(std::size_t offset:{4u,16u,20u}){
                float value=0;std::memcpy(&value,curve.points.data()+point+offset,4);value*=factor;
                if(!std::isfinite(value))throw std::runtime_error("Invalid trick curve value");
                std::memcpy(curve.points.data()+point+offset,&value,4);
            }
            target.curves[index]=std::move(curve);
        }
    }
    void completed(bool enabled){if(!enabled){original={};owned=false;}}
};
}

