#pragma once
#include "trainer_logic.h"
#include "Engine/Core/Json/json.h"
namespace dingosdk::early_trainer::storage_detail {
inline Json encode(const Config& c) {
    Json j=Json::object();j["ollie"]=c.ollie;j["slow"]=c.slow;j["boost"]=c.boost;j["speed_cap"]=c.speed_cap;j["flight"]=c.flight;j["jump"]=c.jump;
    Json binds=Json::array();for(auto b:c.binds){Json row=Json::object();row["key"]=b.key;row["hold"]=b.hold;binds.push_back(row);}j["bindings"]=binds;return j;
}
inline Config decode(const Json& j) {
    Config c;c.ollie=j.value("ollie",c.ollie);c.slow=j.value("slow",c.slow);c.boost=j.value("boost",c.boost);
    c.speed_cap=j.value("speed_cap",c.speed_cap);c.flight=j.value("flight",c.flight);c.jump=j.value("jump",c.jump);
    if(j.contains("bindings")){const auto& b=j.at("bindings");if(!b.is_array()||b.size()!=ActionCount)throw std::runtime_error("Invalid bindings");
        for(int i=0;i<ActionCount;++i){c.binds[i].key=b.at(i).value("key",c.binds[i].key);c.binds[i].hold=b.at(i).value("hold",false);}}
    std::string error;if(!normalize(c,error))throw std::runtime_error(error);return c;
}
}
