#pragma once
#include "trainer_logic.h"
#include "Engine/Core/Json/json.h"
namespace dingosdk::early_trainer::storage_detail {
inline Json encode(const Config& c) {
    Json j=Json::object();j["ollie"]=c.ollie;j["slow"]=c.slow;j["boost"]=c.boost;j["speed_cap"]=c.speed_cap;j["flight"]=c.flight;j["jump"]=c.jump;
    j["ui_scale"]=c.ui_scale;j["slingshot_forward"]=c.slingshot_forward;j["slingshot_up"]=c.slingshot_up;
    Json tweaks=Json::array();for(float x:c.tweaks)tweaks.push_back(x);j["tweaks"]=tweaks;
    Json tb=Json::array();for(auto b:c.tweak_binds){Json row=Json::object();row["key"]=b.key;row["hold"]=b.hold;tb.push_back(row);}j["tweak_bindings"]=tb;
    Json moves=Json::array(), mb=Json::array();for(int i=0;i<MovementCount;++i){moves.push_back(c.movement[i]);Json row=Json::object();row["key"]=c.movement_binds[i].key;row["hold"]=c.movement_binds[i].hold;mb.push_back(row);}j["movement"]=moves;j["movement_bindings"]=mb;
    Json binds=Json::array();for(auto b:c.binds){Json row=Json::object();row["key"]=b.key;row["hold"]=b.hold;binds.push_back(row);}j["bindings"]=binds;return j;
}
inline Config decode(const Json& j) {
    Config c;c.ollie=j.value("ollie",c.ollie);c.slow=j.value("slow",c.slow);c.boost=j.value("boost",c.boost);
    c.speed_cap=j.value("speed_cap",c.speed_cap);c.flight=j.value("flight",c.flight);c.jump=j.value("jump",c.jump);
    c.ui_scale=j.value("ui_scale",1.0f);c.slingshot_forward=j.value("slingshot_forward",20.0f);c.slingshot_up=j.value("slingshot_up",10.0f);
    if(j.contains("tweaks")){const auto& t=j.at("tweaks");if(!t.is_array()||t.size()!=TweakCount)throw std::runtime_error("Invalid trick values");for(int i=0;i<TweakCount;++i)c.tweaks[i]=t.at(i).get<float>();}
    if(j.contains("tweak_bindings")){const auto& t=j.at("tweak_bindings");if(!t.is_array()||t.size()!=TweakCount)throw std::runtime_error("Invalid trick bindings");for(int i=0;i<TweakCount;++i)c.tweak_binds[i]={t.at(i).value("key",0),t.at(i).value("hold",false)};}
    if(j.contains("movement")){const auto& a=j.at("movement");if(!a.is_array()||a.size()!=MovementCount)throw std::runtime_error("Invalid movement values");for(int i=0;i<MovementCount;++i)c.movement[i]=a.at(i).get<float>();}
    if(j.contains("movement_bindings")){const auto& a=j.at("movement_bindings");if(!a.is_array()||a.size()!=MovementCount)throw std::runtime_error("Invalid movement bindings");for(int i=0;i<MovementCount;++i)c.movement_binds[i]={a.at(i).value("key",0),a.at(i).value("hold",false)};}
    if(j.contains("bindings")){const auto& b=j.at("bindings");
        const bool legacy=b.size()==7;
        if(!b.is_array()||(!legacy&&b.size()!=ActionCount))throw std::runtime_error("Invalid bindings");
        for(std::size_t i=0;i<b.size();++i){const auto index=legacy&&i>=5?i+1:i;
            c.binds[index].key=b.at(i).value("key",c.binds[index].key);c.binds[index].hold=b.at(i).value("hold",false);}
    }
    std::string error;if(!normalize(c,error))throw std::runtime_error(error);return c;
}
}
