#pragma once
#include <array>
#include <cmath>
#include <algorithm>
namespace dingosdk::early_trainer {
struct ScalarScale {float before,after;
    ScalarScale(float native,float factor):before(native),after(native*factor){}
    bool restore(float& current) const {if(current!=after)return false;current=before;return true;}
};
inline std::array<float,3> planar_scale(std::array<float,3> value,float factor){value[0]*=factor;value[2]*=factor;return value;}
inline std::array<float,3> air_delta(const std::array<float,16>& basis,float right,float forward,float acceleration,float dt){
    const float x=basis[0]*right-basis[8]*forward,z=basis[2]*right-basis[10]*forward;
    const float length=std::hypot(x,z),scale=acceleration*dt/std::max(1.0f,length);return {x*scale,0,z*scale};
}
// Scale displacement around the skater, never an absolute world coordinate.
inline std::array<float,3> walking_velocity(const std::array<float,3>& root,const std::array<float,3>& target,float factor,float dt){
    if(dt<=0)return {};return {(target[0]-root[0])*factor/dt,0,(target[2]-root[2])*factor/dt};
}
inline float gravity_correction(float native_gravity,float factor,float dt){return native_gravity*(factor-1)*dt;}
// Native ground->falling transition, once. Landing, respawn, gaps and slopes re-arm separately.
struct NativeJumpEdge {
    std::uintptr_t owner=0;bool grounded=false;std::uint64_t stamp=0;
    bool sample(std::uintptr_t who,bool ground,bool falling,float up,std::uint64_t now){
        const bool trigger=owner==who&&now>=stamp&&now-stamp<200&&grounded&&!ground&&falling&&up>0.5f;
        owner=who;grounded=ground;stamp=now;return trigger;
    }
};
}
