#pragma once
#include "Extension/Skater/physics_tuning_model.h"
#include <algorithm>
#include <cmath>
#include <cstring>
#include <stdexcept>
#include <string>
namespace dingosdk::early_trainer {
inline float bounded(float x) { return std::isfinite(x) ? std::clamp(x, 0.25f, 10.0f) : 1.0f; }
inline std::vector<std::uint16_t> height_fields(const physics_tuning::Model& m) {
    std::vector<std::uint16_t> result;
    for (const std::string prefix : {"PhysicsJump.MaxHeightVsSpeed.", "PhysicsJump.MinHeightVsSpeed."}) {
        unsigned count = 0;
        for (std::size_t i=0; i<m.fields.size() && i<m.field_names.size(); ++i) {
            const auto& n=m.field_names[i]; const auto& f=m.fields[i];
            if (!n.starts_with(prefix) || !f.real || f.size!=4) continue;
            const auto leaf=n.substr(prefix.size());
            bool y=false;
            for (int k=0;k<16;++k) if (leaf=="Y"+std::to_string(k)) y=true;
            if (y || leaf=="Min_Y" || leaf=="Max_Y") { result.push_back(f.offset); ++count; }
        }
        if (count!=18) throw std::runtime_error("Ollie height graph layout is unsupported.");
    }
    return result;
}
inline void scale_heights(std::vector<std::uint8_t>& target, const std::vector<std::uint8_t>& baseline,
                          const std::vector<std::uint16_t>& fields, float factor) {
    factor=bounded(factor);
    for (auto offset:fields) {
        if (std::size_t(offset)+4>target.size() || std::size_t(offset)+4>baseline.size())
            throw std::runtime_error("Height field outside tuning asset.");
        float value; std::memcpy(&value,baseline.data()+offset,4); value*=factor;
        if (!std::isfinite(value)) throw std::runtime_error("Height graph contains an invalid value.");
    }
    for (auto offset:fields) {
        float value; std::memcpy(&value,baseline.data()+offset,4); value*=factor;
        std::memcpy(target.data()+offset,&value,4);
    }
}
}
