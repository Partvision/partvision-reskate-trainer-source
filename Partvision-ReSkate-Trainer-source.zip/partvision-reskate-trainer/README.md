# Partvision's ReSkate Trainer

Custom ReSkate 1.0.6 build for Skate Steam build 25414733. Current trainer: **0.4.0-preview5**.

## Features

- Preview 5: fixes speed/gravity writes undoing themselves; corrects local feedback, air-state sampling and jump indicators; adds wait reasons and a physics-step counter. Animation/trajectory jumps remain unsupported.

- Home-key Dear ImGui menu: Home, Player, Lobby, Visual, Performance and Info.
- Preview 4: grouped Player pages, native off-board speed, air steering, local gravity, native jump-edge detection and stronger No Fall landing/collision tuning.
- Preview 3: Force No Fall using native No Bail, optional Hold/Toggle keybind, independent reset and legacy keybind migration.
- Preview 2: ground fastplant graphs and active speed curve fixed; right-click numeric entry above slider ranges with saved custom values.
- New 0.4: experimental footplant tuning, pop preservation, body flips/spins, slingshot, independent resets and UI scaling.
- Player: ollie power, slow motion, speed boost, noclip/fly, experimental off-board jump assistance, keybinds and presets.
- Visual: freecam, freecam FOV 40-120, film grain, vignette and chromatic aberration.
- Performance: FPS comparison, shadow maps and five category-specific cull distances.

Player overrides are solo-only. Local rendering controls are intended to work in multiplayer, but server behavior has not been playtested. Lobby tools, anti-aliasing, sharpness, sky color and Sword Board remain planned.

## Install

Use the packaged preview ZIP, close Skate and its launcher, extract everything and run `Install.cmd`. It verifies the supported executable and backs up the existing launcher/DLL. Start ReSkate and press **Home**.

Read [installation, controls and limitations](packaging/README.md). The new preview has passed build and automated checks, but has not been playtested in-game.

## Roadmap

See [ROADMAP.md](ROADMAP.md) for the updated 0.4–1.0 release plan, priorities, controller menu, online capability states and gameplay overlays. These are planned features; the current build remains 0.4.0-preview5.

## Build

See [BUILD-PARTVISION.md](BUILD-PARTVISION.md) for the Windows CMake/Ninja build and tests. Trainer code is in `Extension/EarlyTrainer`; the complete modified ReSkate source is included so the DLL can be rebuilt.

## Credits and license

Created for Partvision with OpenAI Codex. Based on ReSkate by Dingo-Shenanigans, tag v1.0.6, commit `f815658bf1833ef0580fc87ea1758bfd91ddb361`. Physics and off-board helper adaptations come from Andrew Nakas's ReSkate Trainer. Uses Dear ImGui and bundled dependencies under their respective licenses.

GPL-3.0; see [LICENSE](LICENSE). Original project documentation is preserved in [README-UPSTREAM.md](README-UPSTREAM.md). This is an unofficial fan project, not affiliated with Electronic Arts or Full Circle. You need your own copy of Skate.
